#include <R.h>
#include <Rinternals.h>
#include <stdlib.h> // for NULL
#include <R_ext/Rdynload.h>

/* FIXME:
   Check these declarations against the C/Fortran source code.
*/

/* .Call calls */
extern SEXP _dynWEV_d_2DSD(SEXP, SEXP, SEXP, SEXP, SEXP);  // Arguments: rts, params, precision, boundary, stop_on_error
extern SEXP _dynWEV_d_WEVd(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);  // Arguments: rts, params, precision, c_precision, boundary, stop_on_error
extern SEXP _dynWEV_d_WEVabsmu(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);  // Arguments: rts, params, precision, c_precision, boundary, stop_on_error
extern SEXP _dynWEV_d_WEVmu(SEXP, SEXP, SEXP, SEXP, SEXP);  // Arguments: rts, params, precision, boundary, stop_on_error
extern SEXP _dynWEV_d_IRM(SEXP, SEXP, SEXP, SEXP);  // Arguments: rts, params, boundary, step_width
extern SEXP _dynWEV_d_PCRM(SEXP, SEXP, SEXP, SEXP);  // Arguments: rts, params, boundary, step_width
extern SEXP _dynWEV_dd_IRM(SEXP, SEXP, SEXP, SEXP);  // Arguments: rts, xj, params, boundary, method
extern SEXP _dynWEV_dd_PCRM(SEXP, SEXP, SEXP, SEXP);  // Arguments: rts, xj, params, boundary
extern SEXP _dynWEV_r_RM(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);  // Arguments: n, params, indep, delta, maxT, seed
extern SEXP _dynWEV_r_WEV(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);  // Arguments: n, params, model, delta, maxT, seed
extern SEXP _dynWEV_r_RM_Kiani(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);  // Arguments: n, params, rho, Bl, model, delta, maxT, seed


static const R_CallMethodDef CallEntries[] = {
    {"_dynWEV_d_2DSD",         (DL_FUNC) &_dynWEV_d_2DSD,           5},
    {"_dynWEV_d_WEVd",         (DL_FUNC) &_dynWEV_d_WEVd,           6},
    {"_dynWEV_d_WEVabsmu",         (DL_FUNC) &_dynWEV_d_WEVabsmu,           6},
    {"_dynWEV_d_WEVmu",         (DL_FUNC) &_dynWEV_d_WEVmu,           5},
    {"_dynWEV_d_IRM",         (DL_FUNC) &_dynWEV_d_IRM,           4},
    {"_dynWEV_d_PCRM",         (DL_FUNC) &_dynWEV_d_PCRM,           4},
    {"_dynWEV_dd_IRM",         (DL_FUNC) &_dynWEV_dd_IRM,           5},
    {"_dynWEV_dd_PCRM",         (DL_FUNC) &_dynWEV_dd_PCRM,           4},
    {"_dynWEV_r_RM",         (DL_FUNC) &_dynWEV_r_RM,           6},
    {"_dynWEV_r_WEV",         (DL_FUNC) &_dynWEV_r_WEV,           6},
    {"_dynWEV_r_RM_Kiani",         (DL_FUNC) &_dynWEV_r_RM_Kiani,           7},
    {NULL, NULL, 0}
};

void R_init_dynWEV(DllInfo *dll)
{
    R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
    R_useDynamicSymbols(dll, FALSE);
}
