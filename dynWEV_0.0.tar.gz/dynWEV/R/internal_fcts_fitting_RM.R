### Helper functions for the fitting routine ####

create_grid_RM <- function(init_grid=NULL, nConds, nRatings, time_scaled=FALSE,
                        optim_method="bobyqa", minrt = 0.2,  sym_thetas=FALSE) {
  ## Function that returns the intial grid for the grid search before the optimisation.
  ## Input: model (in "IRM", "PCRM")
  ## Output: a data.frame with rows equal to the initial parameters
  if ( nRatings < 2) {
    stop("There has to be at least two rating levels")
  }
  if (is.null(init_grid)) {
    if (time_scaled) {
      init_grid <- expand.grid(vmin = seq(0.01, 0.2, length.out = 2), ### vmin = drift rate in first condition \in (0,\infty)]
                               vmax = seq(1, 3.8, length.out = 5),     ### vmax = mean drift rate in last condition \in (\vmin,\infty)]
                               a = seq(0.5,1.4, length.out = 3),           ### sz = range of possible start points (unif ditr.; in units of a-z) \in [0,1]
                               b = seq(0.5,1.4, length.out = 3),           ### sz = range of possible start points (unif ditr.; in units of a-z) \in [0,1]
                               theta0 = c(0.1, 5, 20),              ### theta0 = lowest threshold for confidence rating (in difference from threshold / a)
                               thetamax = c(4,15,30),              ### thetamax = highest threshold for confidence rating (in distance from threshold / a)
                               t0 = seq(max(minrt-0.2, 0), max(minrt-0.1, 0)), ### t0 = minimal non-decision time
                               st0 = seq(0.07, 0.5, length.out=3),    ### st0 = range of (uniform dist) non-decision time
                               wrt = seq(0.2, 7, length.out = 3),      ### coeff for time in conf= (b-xj) + (wrt* 1//sqrt(t)) + (wint* (b-xj)/sqrt(t))
                               wint = seq(0.2, 7, length.out = 3))     ### coeff for interaction in conf= (b-xj) + (wrt* 1//sqrt(t)) + (wint* (b-xj)/sqrt(t))
    } else {
      init_grid <- expand.grid(vmin = seq(0.01, 0.2, length.out = 2), ### vmin = drift rate in first condition \in (0,\infty)]
                              vmax = seq(1, 3.8, length.out = 5),     ### vmax = mean drift rate in last condition \in (\vmin,\infty)]
                              a = seq(0.5, 1.4, length.out = 3),           ### sz = range of possible start points (unif ditr.; in units of a-z) \in [0,1]
                              b = seq(0.5, 1.4, length.out = 3),           ### sz = range of possible start points (unif ditr.; in units of a-z) \in [0,1]
                              theta0 = seq(0.1, 0.8,length.out = 3),    ### theta0 = lowest threshold for confidence rating (in difference from threshold / a)
                              thetamax = seq(0.7, 1.1 ,length.out = 3),### thetamax = highest threshold for confidence rating (in distance from threshold / a)
                              t0 = seq(max(minrt-0.2, 0), max(minrt-0.1, 0)), ### t0 = minimal non-decision time
                              st0 = seq(0.07, 0.5, length.out=3))    ### st0 = range of (uniform dist) non-decision time
  }
  }
  init_grid <- subset(init_grid, theta0 < thetamax)
  if (optim_method=="Nelder-Mead") {
    ## change parametrisation (should be on the whole real line) and
    #  span V-parameters between vmin and vmax equidistantly for all conditions
    inits <- data.frame(matrix(data=NA, nrow= nrow(init_grid),
                               ncol = 3+nConds+(nRatings-1)+as.numeric(!sym_thetas)*(nRatings-1)))
    for (i in 0:(nConds-1)){
      if (nConds == 1) {
        inits[,1] <- log((init_grid$vmin+init_grid$vmax)/2)
      } else {
        inits[,i+1] <- log(init_grid$vmin+(i/(nConds-1))^3*(init_grid$vmax-init_grid$vmin)) ###  We assume a different V (mean drift rate) for the different conditions --> nConds parameters
      }
    }
    inits[,nConds+1] <- log(init_grid$a)
    inits[,nConds+2] <- log(init_grid$b)
    inits[,nConds+3] <- log(init_grid$t0)
    inits[,nConds+4] <- log(init_grid$st0)


    inits[,nConds+5] <- init_grid$theta0
    if (nRatings > 2) {
      inits[,(nConds+6):(nConds+3+(nRatings))] <- log((init_grid$thetamax-init_grid$theta0)/(nRatings-2))
    }
    if (!sym_thetas) {
      inits[,nConds+4+nRatings] <- init_grid$theta0
      if (nRatings > 2) {
        inits[,(nConds+5+nRatings):(nConds+2+2*nRatings)] <- log((init_grid$thetamax-init_grid$theta0)/(nRatings-2))
      }
    }
    if (time_scaled) {
      inits <- cbind(inits, log(init_grid$wrt),
                     log(init_grid$wint))
    }

    ##replace all +-Inf with big/tiny numbers
    inits[inits==Inf]<- 1e6
    inits[inits==-Inf]<- -1e6

    return(inits)


  } else {


    if (nConds==1) {
      init_grid$v1 <- (init_grid$vmin+init_grid$vmax)/2
    } else {
      for (i in 0:(nConds-1)){
        init_grid[paste("v", i+1, sep="")] <- init_grid$vmin+(i/(nConds-1))^3*(init_grid$vmax-init_grid$vmin)
      }
    }

    if (sym_thetas) {
      init_grid["theta1"] <- init_grid$theta0
      if (nRatings > 2) {
        for (i in 2:(nRatings-1)) {
          init_grid[paste("dtheta", i, sep="")] <- (init_grid$thetamax-init_grid$theta0)/(nRatings-2)
        }
        cols_theta <- c("theta1", paste("dtheta", 2:(nRatings-1), sep=""))
      } else {
        cols_theta <- c("theta1")
      }
    } else {
      init_grid[c("thetaUpper1", "thetaLower1")] <- init_grid$theta0
      if (nRatings > 2) {
        for (i in 2:(nRatings-1)) {
          init_grid[paste(c("dthetaUpper", "dthetaLower"), i, sep="")] <- (init_grid$thetamax-init_grid$theta0)/(nRatings-2)
        }
        cols_theta <- c('thetaLower1', paste("dthetaLower", 2:(nRatings-1), sep=""),
                        'thetaUpper1', paste("dthetaUpper", 2:(nRatings-1), sep=""))
      } else {
        cols_theta <- c("thetaLower1", "thetaUpper1")
      }
    }
    return(init_grid[c('a', 'b', 't0', 'st0',  rep(c('wrt','wint'), as.numeric(time_scaled)),
                       paste("v", 1:nConds, sep=""),
                       cols_theta)])
  }
}


neglikelihood_free_RM <-   function(p, data, model, time_scaled,
                                nConds, nRatings, sym_thetas)
{
  # get parameter vector back from real transformations
  p <- c(t(p))

  paramDf <-  data.frame(matrix(nrow=1, ncol=0))
  paramDf[,paste("v",1:(nConds), sep="")] <- exp(p[1:(nConds)])
  paramDf$a <- exp(p[(1+nConds)])
  paramDf$b <- exp(p[2+nConds])
  paramDf$t0 <- exp(p[3+nConds])
  paramDf$st0 <- exp(p[4+nConds])
  if (time_scaled) {
    paramDf$wx <- 1/(exp(p[length(p)-1])+exp(p[length(p)])+1)
    paramDf$wrt <- exp(p[length(p)-1])/(exp(p[length(p)-1])+exp(p[length(p)])+1)
    paramDf$wint <- exp(p[length(p)])/(exp(p[length(p)-1])+exp(p[length(p)])+1)
  } else {
    paramDf$wx <- 1
    paramDf$wrt <- 0
    paramDf$wint <- 0
  }

  if (nRatings > 2) {
    if (sym_thetas) {
      paramDf[,paste("theta",1:(nRatings-1), sep="")] <- cumsum(c(p[nConds+5], exp(p[(nConds+6):(nConds+3+nRatings)])))
    } else {
      paramDf[,paste("thetaUpper",1:(nRatings-1), sep="")] <- cumsum(c(p[nConds+5], exp(p[(nConds+6):(nConds+3+nRatings)])))
      paramDf[,paste("thetaLower",1:(nRatings-1), sep="")] <- cumsum(c(p[nConds+4+nRatings], exp(p[(nConds+5+nRatings):(nConds+2+2*nRatings)])))
    }
  } else {
    if (sym_thetas) {
      paramDf[,paste("theta",1:(nRatings-1), sep="")] <- p[nConds+5]
    } else {
      paramDf[,paste("thetaUpper",1:(nRatings-1), sep="")] <- p[nConds+5]
      paramDf[,paste("thetaLower",1:(nRatings-1), sep="")] <- p[nConds+4+nRatings]
    }
  }
  if (any(is.infinite(t(paramDf))) || any(is.na(t(paramDf)))) {
    return(1e12)
  }
  negloglik <- -LogLikRM(data, paramDf, model, time_scaled)

  return(negloglik)
}




neglikelihood_bounded_RM <-   function(p, data, model, time_scaled,
                                nConds, nRatings, sym_thetas=FALSE)
{
  # get parameter vector back from real transformations
  paramDf <- p
  pnames <- names(paramDf)
  if (nRatings > 2) {
    if (sym_thetas) {
      paramDf[paste("theta", 2:(nRatings-1))] <- c(t(paramDf['theta1'])) + c(t(cumsum(paramDf[grep(pnames, pattern = "dtheta", value=TRUE)])))
    } else {
      paramDf[paste("thetaUpper", 2:(nRatings-1), sep="")] <- c(t(paramDf['thetaUpper1'])) + cumsum(c(t(paramDf[grep(pnames, pattern = "dthetaUpper", value=TRUE)])))
      paramDf[paste("thetaLower", 2:(nRatings-1), sep="")] <- c(t(paramDf['thetaLower1'])) + cumsum(c(t(paramDf[grep(pnames, pattern = "dthetaLower", value=TRUE)])))
    }
    paramDf <- paramDf[ -grep(names(paramDf), pattern="dtheta")]
  }
  if (!is.data.frame(paramDf)) {
    paramDf2 <-   data.frame(matrix(nrow=1, ncol=length(paramDf)))
    paramDf2[1,] <- paramDf
    names(paramDf2) <- names(paramDf)
    paramDf <- paramDf2
  }
  if (!time_scaled) {
    paramDf$wx <- 1
    paramDf$wrt <- 0
    paramDf$wint <- 0
  } else {
    paramDf$wx <- 1/(paramDf$wrt+paramDf$wint+1)
    paramDf$wrt <- paramDf$wrt/(paramDf$wrt+paramDf$wint+1)
    paramDf$wint <- paramDf$wint/(paramDf$wrt+paramDf$wint+1)
  }
  negloglik <- -LogLikRM(data, paramDf, model, time_scaled)
  return(negloglik)
}

fill_thresholds_RM <- function(res, used_cats, actual_nRatings) {
  ### This function fills up the missing confidence thresholds with the best/easiest choices
  ### for the not identifiable or not reasonably fittable thresholds because some confidence
  ### categories are not used by the subject
  ### ToDo:   For sym_thetas==FALSE, use different nRatings for lower and upper responses in fitting
  symmetric_confidence_thresholds <- length(grep(pattern = "thetaUpper", names(res), value = T))<1
  if (symmetric_confidence_thresholds) {
    thetas <- rep(NA,(actual_nRatings-1))
    names(thetas) <- paste("theta", 1:(actual_nRatings-1), sep="")
    thetas[paste("theta", (used_cats[used_cats<max(used_cats)]), sep="")] <- c(t(res[,grep(pattern = "theta[0-9]", names(res), value = T)]))
    if (min(used_cats) >1) {
      thetas[paste("theta", 1:(min(used_cats)-1), sep="")] <- min(0, min(thetas, na.rm = TRUE))
    }
    if (max(used_cats)<actual_nRatings) {
      thetas[paste("theta", (max(used_cats):(actual_nRatings-1)), sep="")] <- max(1e+24, max(thetas, na.rm=TRUE))
    }
    thetas[which(is.na(thetas))] <- thetas[(which(is.na(thetas))-1)]
    res[,names(thetas)]<- thetas
  } else {
    thetasUpper <- rep(NA,(actual_nRatings-1))
    thetasLower <- rep(NA,(actual_nRatings-1))
    names(thetasUpper) <- paste("thetaUpper", 1:(actual_nRatings-1), sep="")
    names(thetasLower) <- paste("thetaLower", 1:(actual_nRatings-1), sep="")
    thetasUpper[paste("thetaUpper", (used_cats[used_cats<max(used_cats)]), sep="")] <- c(t(res[,grep(pattern = "thetaUpper", names(res), value = T)]))
    thetasLower[paste("thetaLower", (used_cats[used_cats<max(used_cats)]), sep="")] <- c(t(res[,grep(pattern = "thetaLower", names(res), value = T)]))
    if (min(used_cats) >1) {
      thetasUpper[paste("thetaUpper", 1:(min(used_cats)-1), sep="")] <- min(0, min(thetasUpper, na.rm=TRUE))
      thetasLower[paste("thetaLower", 1:(min(used_cats)-1), sep="")] <- min(0, min(thetasLower, na.rm=TRUE))
    }
    if (max(used_cats)<actual_nRatings) {
      thetasUpper[paste("thetaUpper", (max(used_cats):(actual_nRatings-1)), sep="")] <- max(1e+24, max(thetasUpper, na.rm = TRUE))
      thetasLower[paste("thetaLower", (max(used_cats):(actual_nRatings-1)), sep="")] <- max(1e+24, max(thetasLower, na.rm = TRUE))
    }
    while (any(is.na(thetasUpper))) {
      thetasUpper[which(is.na(thetasUpper))] <- thetasUpper[(which(is.na(thetasUpper))-1)]
    }
    while (any(is.na(thetasLower))) {
      thetasLower[which(is.na(thetasLower))] <- thetasLower[(which(is.na(thetasLower))-1)]
    }

    res[,names(thetasUpper)]<- thetasUpper
    res[,names(thetasLower)]<- thetasLower
  }
  res
}
