#' Response Time Distributions and Confidence Judgments.
#'
#' \tabular{ll}{
#' Package: \tab dynWEV\cr
#' Type: \tab Package\cr
#' Version: \tab 0.0\cr
#' Date: \tab 2021-03-05\cr
#' Depends: \tab R (>= 3.5.0)\cr
#' License: \tab GPL (>=3)\cr
#' URL: \tab https://gitlab.pavlovia.org/SeHellmann\cr
#' }
#'
#' Provides response time distributions (density/PDF) for the 2DSD model and dWEV model of decision confidence.
#'
#' @aliases dynWEV-package dWEV-package 2DSD-package
#' @name dynWEV-package
#' @docType package
#' @title The dynWEV Package
#' @author Sebastian Hellmann based on Henrik Singmann, Scott Brown, Matthew Gretton, Andrew Heathcote
#' @keywords package
NULL
