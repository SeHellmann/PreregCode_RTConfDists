### Helper functions for predictratingdist ####

adapt_theta <- function(thetas_lower, thetas_upper, model,tmax,  # Adapt integration limits in C for extreme confidence responses
                        V, SV, nRatings, paramDf) {

  eps <- .Machine$double.xmin
  t <- c(paramDf$t0, tmax)
  if (model=="WEVabsmu") {
    # if (sigmu==0) {    ### does not work properly, yet
    #    return(thetas_lower, thetas_upper)
    # }
    int_limit <-0
    for ( i in 1:length(SV)){
      sv <- SV[i]
      if (paramDf$sigmu==0) {
        paramDf$sigmu <- eps
      }
      sig2_c <- with(paramDf,
                     (1-w)^2/(w^2*tau^2)*((t+tau)*sig^2+(t+tau)^2*sigmu^2)+1/tau+sv^2/(sv^2*t+1))
      int_limit <- max(sqrt(sig2_c)*sqrt(-log(sqrt(pi)*sqrt(sig2_c)*eps)), int_limit)
    }
  }
  if (model=="WEVd") {
    if (all(SV==0)) {
      return(thetas_lower, thetas_upper)
    }

    q <- (paramDf$w/(1-paramDf$w)*paramDf$tau/(paramDf$tau+t))
    sig2_c <- q^2/paramDf$tau+paramDf$sig^2/(t+paramDf$tau)

    for (i in 1:length(V)) {
      v <- V[i]
      sv <- SV[i]
      int_limit <- 0
      if (sv!=0) {

        sigma2_plus <- sig2_c + ((sv^2*(1+q)^2)/(sv^2*t+1))
        sigma2_minus <- sig2_c + ((sv^2*(1-q)^2)/(sv^2*t+1))

        sig_c_tilde <- sqrt(apply(matrix(c(sigma2_minus, sigma2_plus), nrow=2), 1, max))
        mu_plus <- abs((1+q)*(v-paramDf$z*paramDf$a*sv^2)/(sv^2*t+1))
        mu_minus <- abs((1-q)*(v-paramDf$z*paramDf$a*sv^2)/(sv^2*t+1))
        max_mu <- apply(matrix(c(mu_minus, mu_plus), nrow=2), 1, max)

        int_limit <- max(sig_c_tilde*sqrt(-log(sqrt(pi)*sig_c_tilde*eps))+max_mu, int_limit)
      }
    }
  }
  int_limit <- max(int_limit, max(thetas_lower[2:nRatings], thetas_upper[2:nRatings])+4)
  thetas_upper[c(1, (nRatings+1))] <- c(-int_limit,  int_limit)
  thetas_lower[c(1, (nRatings+1))] <- c(-int_limit,  int_limit)
  return(thetas = c(thetas_lower, thetas_upper))
}

#Actual function for integrating and calculating the probabilities
preddist <- function(row, thetas_lower, thetas_upper, paramDf,V, SV, model,
                     precision=3, c_precision=200,
                     maxrt=15, subdivisions=100L,
                     stop.on.error = FALSE,
                     .progress = TRUE, pb=NULL) {
  if (model != "2DSD") {
    vth1 <- ifelse(row$response =="upper", thetas_upper[row$rating], thetas_lower[(row$rating)])
    vth2 <- ifelse(row$response =="upper", thetas_upper[(row$rating+1)], thetas_lower[(row$rating+1)])
  } else {
    vth1 <- ifelse(row$response =="upper", thetas_upper[row$rating], rev(thetas_lower)[(row$rating+1)])
    vth2 <- ifelse(row$response =="upper", thetas_upper[(row$rating+1)], rev(thetas_lower)[(row$rating)])
  }


  integrand <- with(paramDf, switch(which(model== c("WEVmu", "WEVd", "WEVabsmu", "2DSD")),
                                    function(t) return(dWEVmu(t, vth1,vth2,
                                                                  response=as.character(row$response), tau=tau, a=a,
                                                                  v = (-1)^(row$stimulus=="lower")*V[row$condition],
                                                                  t0 = t0, z = z, sz = sz, st0=st0,
                                                                  sv = SV[row$condition], w=w, sig=sig, sigmu=sigmu,
                                                                  z_absolute = FALSE, precision = precision)),
                                    function(t) return(dWEVd(t, vth1,vth2,
                                                                 response=as.character(row$response), tau=tau, a=a,
                                                                 v = (-1)^(row$stimulus=="lower")*V[row$condition],
                                                                 t0 = t0, z = z, sz = sz, st0=st0,
                                                                 sv = SV[row$condition], w=w, sig=sig,
                                                                 z_absolute = FALSE,
                                                                 precision = precision, c_precision = c_precision)),
                                    function(t) return(dWEVabsmu(t, vth1,vth2,
                                                                     response=as.character(row$response), tau=tau, a=a,
                                                                     v = (-1)^(row$stimulus=="lower")*V[row$condition],
                                                                     t0 = t0, z = z, sz = sz, st0=st0,
                                                                     sv = SV[row$condition], w=w, sig=sig, sigmu=sigmu,
                                                                     z_absolute = FALSE,
                                                                     precision = precision, c_precision = c_precision)),
                                    function(t) return(d2DSD(t, vth1,vth2,
                                                             response=as.character(row$response), tau=tau, a=a,
                                                             v = (-1)^(row$stimulus=="lower")*V[row$condition],
                                                             t0 = t0, z = z, sz = sz, st0=st0,
                                                             sv = SV[row$condition],
                                                             z_absolute = FALSE, precision = precision))))


  p <- integrate(integrand, lower=paramDf$t0, upper=maxrt, subdivisions = subdivisions,
                 stop.on.error = stop.on.error)
  if (.progress) pb$tick()
  return(data.frame(p = p$value, info = p$message, err = p$abs.error))
}

