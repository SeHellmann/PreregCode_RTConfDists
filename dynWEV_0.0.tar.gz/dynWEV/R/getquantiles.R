#' Get Quantiles from predicted Reaction Time density
#'
#' Computes the quantiles from a vector of reaction time density values within
#' groups of conditions, correct/incorrect answers and confidence ratings (if
#' available).
#'
#' @param pred dataframe. Should have at least two columns: rt (for reaction times)
#' and dens or densscaled. All other columns will be used as grouping factors.
#' As input for pred, the output of predictWEV_RT can be used.
#' @param p numeric vector. Probabilities for returned quantiles. Default:
#' c(.1, .3, .5, .7, .9).
#' @param agg_over character. Names of columns to aggregate over (using the mean of
#' densities, which is valid only, if groups occur with equal probabilities) before
#' computing the quantiles.
#' @param ignore character. Names of columns to be ignored and not used as grouping
#' factor or anything else in the analysis (i.e. "densscaled", if one want to enforce
#' the usage of an available column "dens")
#'
#' @return A vector of quantiles of the same length as p.
#'
#' @details The RTs in the input data frame should be equidistant, i.e. the difference
#' between consecutive RT-values should be constant. For a reasonable accuracy the number
#' of steps in the input should be very high, i.e. the distant between rt values small.
#' The precision of the output is bounded from above by the step size of the RTs in the input.
#'
#' If available, the column densscaled will be preferred (if not given in \code{ignore}).
#' If the column dens is used, it will be scaled by the summed probability.
#'
#' Attention should be given to the columns of pred other then rt and dens/densscaled, because
#' the quantiles are computed
#'
#' @references Pleskac, T. J., & Busemeyer, J. R. (2010). Two-Stage Dynamic Signal Detection:
#' A Theory of Choice, Decision Time, and Confidence, \emph{Psychological Review}, 117(3),
#' 864-901. doi:10.1037/a0019737
#'
#' Rausch, M., Hellmann, S., & Zehetleitner, M. (2018). Confidence in masked orientation
#' judgments is informed by both evidence and visibility. \emph{Attention, Perception, &
#' Psychophysics}, 80(1), 134–154.  doi: 10.3758/s13414-017-1431-5
#'
#'
#' @author Sebastian Hellmann.
#'
#' @useDynLib dynWEV, .registration = TRUE
#'
#' @name RTDensityToQuantiles
#' @import dplyr
#' @importFrom magrittr %>%
#' @importFrom rlang .data
#' @aliases getquantiles getRTquantiles
#' @importFrom Rcpp evalCpp
#'


#' @rdname RTDensityToQuantiles
#' @export
RTDensityToQuantiles <- function(pred, p = c(.1,.3,.5,.7,.9),
                                 agg_over = NULL, ignore = NULL){
  pred <- ungroup(pred)
  names(pred) <- tolower(names(pred))
  if (!is.null(ignore)) {
    pred <- select(pred, -tolower(ignore))
  }
  dts <- table(diff(pred$rt))
  dts <- dts[dts > 400]
  if (length(dts)==0) {
    stop("There are too few rows with an equally spaced distance between successive RT's.")
  }
  dt <- sum(as.numeric(names(dts))*dts)/sum(dts)

  if ("densscaled" %in% names(pred)) {
    if ("dens"  %in% names(pred)) {
      pred <- select(pred, -"dens")
    }
  } else {
    if (!("dens" %in% names(pred))) {
      stop("At least dens or densscaled should be a column of pred (and not ignored)")
    }
    pred <- pred %>% group_by(pred[,setdiff(names(pred), c("rt", "dens"))]) %>%
      mutate(p=sum(.data$dens)*dt,
             densscaled = .data$dens/.data$p) %>%
      select(-c("p", "dens"))
  }

  pred <- pred %>% group_by(pred[, setdiff(names(pred), c("rt", "densscaled"))]) %>%
    mutate(cdfscaled= cumsum(.data$densscaled)*dt) %>%
    select(-"densscaled")
  if (!is.null(agg_over)) {
    pred <- pred %>% group_by(pred[,setdiff(names(pred), c("q", agg_over))]) %>%
      summarise(cdfscaled = mean(.data$cdfscaled))
  }
  pred <- pred %>% group_by(pred[, setdiff(names(pred), c("rt", "cdfscaled"))]) %>%
    summarise(get_quantiles_subgroup(.data$cdfscaled, .data$rt, probs = p))

  pred
}
