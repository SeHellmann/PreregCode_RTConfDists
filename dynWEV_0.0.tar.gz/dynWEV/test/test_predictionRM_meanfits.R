
# 0. Load packages and set parameter set:
cat("\014")
rm(list=ls())
library(tidyverse)
library(dynWEV)
library(ggpubr)

load("../AccumulatorModels/saved_data/fits_RacingModels.RData")
nConds <- 5
nRatings <-5
trimmean <- function(x) {
  x <- x[x<100]
  mean(x)
}
modelparamDf <- fits_RMmodels %>% group_by(model) %>%
  summarise(across(.cols = 2:18, .fns = trimmean))
modelparamDf




delta = 0.002
maxrt = 15
n = 500

i <- 1
paramDf <- modelparamDf[1,]

model = paramDf$model
simus <- rRM(paramDf=paramDf, n=n, model=model, time_scaled = FALSE, gamma=FALSE, agg_simus=FALSE,
                  delta=delta, maxrt = maxrt)
simus <- filter(simus, response !=0)

pred_conf <- predictRM_Conf(paramDf, model=model, time_scaled = FALSE, maxrt = maxrt, subdivisions = 1000)
pred_RT <- predictRM_RT(paramDf, model=model, time_scaled = FALSE, maxrt = maxrt, subdivisions = 500,
                        scaled=TRUE, DistConf = pred_conf)


## Compare to computed RT-densities for ratings:

head(simus)

pred_RT_aggcond <- pred_RT %>%  group_by(correct, rating, rt) %>%
  summarise(dens=mean(dens), densscaled=mean(densscaled)) %>%
  mutate(rating=factor(rating, levels=1:5, labels=c("Guessing", "unsure", "a bit sure", "rather sure", "completely sure")),
         correct=factor(correct,levels=0:1, labels=c("Wrong", "Correct")))
simus2 <- simus %>%
  mutate(rating=factor(rating, levels=1:5, labels=c("Guessing", "unsure", "a bit sure", "rather sure", "completely sure")),
         correct=factor(correct,levels=0:1, labels=c("Wrong", "Correct")))

head(pred_RT_aggcond)
# install.packages("ggpubr")
#library(ggpubr)
p1 <- ggplot()+
  geom_density(data=simus2, aes(x=rt, fill=interaction(rating, correct), group=interaction(rating, correct), y=..count../(2*nrow(simus2))),
               position ="stack", bw=0.07)+
  xlim(c(0,quantile(simus2$rt, probs = 0.95) ))
p2 <- ggplot(pred_RT_aggcond)+
  geom_area(aes(x=rt, y=dens,fill=interaction(rating, correct), group=interaction(rating, correct)),
            col="black",
            position = "stack", stat = "identity")+
  xlim(c(0,quantile(simus2$rt, probs = 0.95) ))
ggarrange(p1, p2, common.legend = TRUE, legend = "bottom")

head(simus2)

load("test/dataRausch2018.RData")
Data <- Data %>% mutate(rating=factor(rating, levels=1:5, labels=c("Guessing", "unsure", "a bit sure", "rather sure", "completely sure")),
                correct=factor(correct,levels=0:1, labels=c("Wrong", "Correct")))
p1 <- ggplot()+
  geom_density(data=Data, aes(x=rt, fill=interaction(rating, correct), group=interaction(rating, correct), y=..count../(2*nrow(Data))),
               position ="stack", bw=0.07)+
  xlim(c(0,quantile(Data$rt, probs = 0.95) ))
p2 <- ggplot(pred_RT_aggcond)+
  geom_area(aes(x=rt, y=dens,fill=interaction(rating, correct), group=interaction(rating, correct)),
            col="black",
            position = "stack", stat = "identity")+
  xlim(c(0,quantile(Data$rt, probs = 0.95) ))
ggarrange(p1, p2, common.legend = TRUE, legend = "bottom")




p1 <- ggplot()+
  geom_density(data=Data, aes(x=rt, fill=interaction(rating, correct), group=interaction(rating, correct), y=..density..),
               position ="stack", bw=0.07)+
  xlim(c(0,quantile(Data$rt, probs = 0.95) ))
p2 <- ggplot(pred_RT_aggcond)+
  geom_area(aes(x=rt, y=densscaled,fill=interaction(rating, correct), group=interaction(rating, correct)),
            col="black",
            position = "stack", stat = "identity")+
  xlim(c(0,quantile(Data$rt, probs = 0.95) ))
ggarrange(p1, p2, common.legend = TRUE, legend = "bottom")







p1 <- ggplot()+
  geom_density(data=simus2, aes(x=rt, fill=interaction(rating, correct), group=interaction(rating, correct), y=..count../(10*nrow(simus2))),
               position ="fill", bw=0.15)+
  xlim(c(0,quantile(simus2$rt, probs = 0.95) ))
p2 <- ggplot(pred_RT_aggcond)+
  geom_area(data=pred_RT_aggcond, aes(x=rt, y=dens,fill=interaction(rating, correct), group=interaction(rating, correct)),
            position = "fill", stat = "identity")+
  xlim(c(0,quantile(simus2$rt, probs = 0.95) ))
ggarrange(p1, p2, common.legend = TRUE, legend = "bottom")


p1 <- ggplot()+
  geom_density(data=Data, aes(x=rt, fill=interaction(rating, correct), group=interaction(rating, correct), y=..count../(2*nrow(Data))),
               position ="fill", bw=0.15)+
  xlim(c(0,quantile(Data$rt, probs = 0.95) ))
p2 <- ggplot(pred_RT_aggcond)+
  geom_area(data=pred_RT_aggcond, aes(x=rt, y=dens,fill=interaction(rating, correct), group=interaction(rating, correct)),
            position = "fill", stat = "identity")+
  xlim(c(0,quantile(Data$rt, probs = 0.95) ))
ggarrange(p1, p2, common.legend = TRUE, legend = "bottom")


ggplot(simus2) +
  geom_density(aes(x=rt, colour="Simus", group=correct, y=..count../nrow(simus2)))+
  geom_line(data=pred_RT_aggcond, aes(x=rt, y=dens, colour="Comp", group=correct))+
  facet_grid(correct~rating)+
  xlim(c(0,quantile(simus2$rt, probs = 0.95) ))
aggSimus <- simus2 %>% group_by(correct, rating, condition) %>%
  summarise(p=n()*5/nrow(simus2))
sum(aggSimus$p)
agg_pred <- pred_conf %>% group_by(rating, correct, condition) %>%
  summarise(p = mean(p)) %>%
  mutate(correct=factor(correct,levels=0:1, labels=c("Wrong", "Correct")))
sum(agg_pred$p)
aggData <- Data %>% group_by(correct, rating, condition) %>%
  summarise(p=n()*5/(2*nrow(Data))) %>%
  mutate(condition = as.numeric(as.factor(condition)))
ggplot()+
  geom_bar(data=aggData, aes(x=rating, y=p, fill=correct), stat="identity", position="dodge")+
  geom_point(data=agg_pred, aes(x=rating, y=p, fill=correct, shape="simus"),position = position_dodge(1))+
  geom_point(data=agg_pred, aes(x=rating, y=p, fill=correct, shape="pred"), position = position_dodge(1))+
  facet_grid(.~condition)
