###########################################################################
#####            Comparison dynWEV vs. 2DSD model               #######
###########################################################################

# ? Sebastian Hellmann, 07.04.2021

# 1) Read in data and drop outliers
# 2) fit the models (dynWEV and 2DSD)
# 3) Predict the RT & confidence distribution for the different models
# 4) Plot the predictions together with empirical distributions
# 5) Analyse covariances between parameters


rm(list=ls())


# #library(R.utils)
# library(plyr)
# library(snow)
# library(doSNOW)
# #library(BayesFactor)
# #library(Hmisc)
# #library(effsize)
# #library(drc)
# library(ggplot2)
library(tidyverse)
library(dynWEV)
library(parallel)
library(magrittr)
library(minqa)


# 1) Read in data

load("test/dataRausch2018.RData")

## drop "outliers"
Data <- Data %>% group_by(participant)
Ntrials <-  Data %>%
  summarise(Ntot = sum(n()))

Data <- Data %>% filter(rt < mean(rt)+4*sd(rt)  & rt>.3 & Rating1RT>.15)
Ntrials_analysis <- Data %>%
  summarise(Ntot = sum(n()))
### proportion of excluded trials
summary((Ntrials$Ntot-Ntrials_analysis$Ntot)/Ntrials$Ntot)
min(Ntrials_analysis$Ntot)


data <- subset(Data, participant==22)

model = "WEVmu"
method="ML"
restr_tau =1
sym_thetas = FALSE
init_grid = NULL
precision=3
logging=FALSE
nRatings <- 5
opts=list()
source("R/internal_fcts_fitting.R")
optim_method="Nelder-Mead"
optim_method = "bobyqa"
mint0 <- min(data$rt)
data_names = list()
grid_search = TRUE
useparallel = FALSE
n.cores = NULL
init_grid <- NULL

fitWEV(data, model, method, restr_tau, sym_thetas, init_grid, precision, logging,
       opts = list(maxit = 1000), optim_method = optim_method)


inits <- inits[sample(1:nrow(inits), size=floor(0.05*nrow(inits))),]
inits <- inits[sample(1:nrow(inits), size=floor(0.05*nrow(inits))),]
inits <- inits[sample(1:nrow(inits), size=floor(0.2*nrow(inits))),]
clusterExport(cl, c("neglikelihood_bounded", "neglikelihood_free"), envir = environment())
clusterExport(cl, c("LogLikWEV"), envir = environment())
clusterEvalQ(cl, library(minqa))

# 2) fit models

n.cores <- parallel::detectCores() - 4
cl <- makeCluster(n.cores, "SOCK", outfile="")
registerDoSNOW(cl)
clusterEvalQ(cl, library(dynWEV))
Data <- cbind(rbind(Data, Data), model=rep(c("2DSD", "WEVmu"), each=nrow(Data)))

t00 <- Sys.time()
fits_models <- ddply(Data,.(participant, model),
                              function(df) fitWEV(df, df$model[1], logging=TRUE),
                              .parallel = T)
stopCluster(cl)

dir.create("saved_data")
save(file="saved_data/fits_2DSD_WEV.RData", fits_models)
passed_time <- as.character(round(as.double(difftime(Sys.time(),t00,units = "mins")), 2))
print(paste("Fitting 2DSD and WEV took...",passed_time," mins"))

