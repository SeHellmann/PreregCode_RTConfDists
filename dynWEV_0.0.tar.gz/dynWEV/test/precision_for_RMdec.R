library(rtdists)
library(dynWEV)
library(tidyverse)
n <- 500 # must be 0 (mod 2)

rt <- seq(0.2, 7, length.out=n)
ST0 <- c(0.002, 0.05, 0.1, 0.2, 0.5)
response <- rep(c(1, 2), n/2)
Times_diffusion <- NULL

#paramDf <- data.frame(a= 2, z = 1, sz=0.2, v=1, )
p <- 3
for (i in 1:length(ST0)) {
  t00 <- Sys.time()
  #  Times_diffusion[i] <- system.time(
  ddiffusion(rt=rt, response=rep(c(1, 2), n/2), a= 2, v=1, t0=0.14, z=1, sz=0.2, sv=0.1, st0=ST0[i], precision=p)
  Times_diffusion[i] <- as.numeric(difftime(Sys.time(), t00, units = "sec"))
}

Times_RMdec <- NULL
p=3
## p ~ ln(a * 10^6) / b    then a*exp(-b*p) ~ 10^-6
#p =
#
#
#  log(0.089045* 10^6) / 1.037580

n <- 100
rt <- seq(0.2, 7, length.out=n)
response <- rep(c(1, 2), n/2)

P <- c(3, 5, 7)
ST0 <- c(0, 0.1, 0.2, 0.8)


Times_RMdec <- matrix(NA, nrow=length(ST0), ncol = length(P))
colnames(Times_RMdec) <- paste("P", P, sep="")
rownames(Times_RMdec) <- paste("ST0", ST0, sep="")
params <- data.frame(a=2, b=2, mu1=0.5, mu2=-0.5, t0=0.14, s=1, th1=0, th2=1e64)
densities <- data.frame(rt=rep(rt, length(ST0)))
densities$ST0 <- rep(ST0, each=n)

for (i in 1:length(ST0)) {
  for (j in 1:length(P)) {
    t00 <- Sys.time()
    #  Times_diffusion[i] <- system.time(
    params$st0 <- ST0[i]
    p <- P[j]
    densities[[paste("p", p, sep="")]][((1:n)+100*(i-1))] <-
      dIRM(rt=rt, response=rep(c(1, 2), n/2), params, time_scaled = FALSE, step_width = 0.089045 * exp(-1.037580*p))
    Times_RMdec[i,j] <- as.numeric(difftime(Sys.time(), t00, units = "sec"))
  }
}

densities$err3 <- densities$p7- densities$p3
densities$err5 <- densities$p7- densities$p5

Times_RMdec
ggplot(densities) +
  geom_boxplot(aes(x=as.factor(ST0), y=err3, col=as.factor(ST0), group=as.factor(ST0)))

ggplot(densities) +
  geom_boxplot(aes(x=as.factor(ST0), y=err5, col=as.factor(ST0), group=as.factor(ST0)))
