
# 0. Load packages and set parameter set:
cat("\014")
rm(list=ls())
library(tidyverse)
library(dynWEV)
library(ggpubr)

load("../AccumulatorModels/saved_data/fits_2DSD_WEV.RData")
nConds <- 5
nRatings <-5
trimmean <- function(x) {
  x <- x[x<100 & x > -100]
  mean(x)
}
names(fits_WEVmodels)
modelparamDf <- fits_WEVmodels %>% group_by(model) %>%
  summarise(across(.cols = c(2:21, 28:30), .fns = trimmean))
modelparamDf


delta = 0.002
maxrt = 15
n = 50000

i <- 1
paramDf <- modelparamDf[2,]
paramDf$t0 <- min(filter(fits_WEVmodels, model=="WEVmu")$t0)
model = paramDf$model
simus <- simulateWEV(paramDf=paramDf, n=n, model=model, gamma=FALSE, agg_simus=FALSE,
                  delta=delta, maxrt = maxrt)
simus <- filter(simus, response !=0)

pred_conf <- predictWEV_Conf(paramDf, model=model, maxrt = maxrt, subdivisions = 1000)
pred_RT <- predictWEV_RT(paramDf, model=model, maxrt = maxrt, subdivisions = 500,
                        scaled=TRUE, DistConf = pred_conf)


## Compare to computed RT-densities for ratings:

head(simus)

pred_RT_aggcond <- pred_RT %>%  group_by(correct, rating, rt) %>%
  summarise(dens=mean(dens), densscaled=mean(densscaled)) %>%
  mutate(rating=factor(rating, levels=1:5, labels=c("Guessing", "unsure", "a bit sure", "rather sure", "completely sure")),
         correct=factor(correct,levels=0:1, labels=c("Wrong", "Correct")))
simus2 <- simus %>%
  mutate(rating=factor(rating, levels=1:5, labels=c("Guessing", "unsure", "a bit sure", "rather sure", "completely sure")),
         correct=factor(correct,levels=0:1, labels=c("Wrong", "Correct")))

head(pred_RT_aggcond)
# install.packages("ggpubr")
#library(ggpubr)
p1 <- ggplot()+
  geom_density(data=simus2, aes(x=rt, fill=interaction(rating, correct), group=interaction(rating, correct), y=..count../(nrow(simus2))),
               position ="stack", bw=0.07)+
  xlim(c(paramDf$t0,quantile(simus2$rt, probs = 0.95) ))+ylim(c(0, 1.7))
p2 <- ggplot(pred_RT_aggcond)+
  geom_area(aes(x=rt, y=dens,fill=interaction(rating, correct), group=interaction(rating, correct)),
            col="black",
            position = "stack", stat = "identity")+
  xlim(c(paramDf$t0,quantile(simus2$rt, probs = 0.95) ))+ylim(c(0, 1.7))
ggarrange(p1, p2, common.legend = TRUE, legend = "bottom")

head(simus2)

load("test/dataRausch2018.RData")
Data <- Data %>% mutate(rating=factor(rating, levels=1:5, labels=c("Guessing", "unsure", "a bit sure", "rather sure", "completely sure")),
                correct=factor(correct,levels=0:1, labels=c("Wrong", "Correct")))
Data <- Data %>% filter(rt < mean(rt)+4*sd(rt)  & rt>.3 & Rating1RT>.15)
p1 <- ggplot()+
  geom_density(data=Data, aes(x=rt, fill=interaction(rating, correct), group=interaction(rating, correct), y=..count../(nrow(Data))),
               position ="stack", bw=0.07)+
  xlim(c(paramDf$t0,max(Data$rt)))+ylim(c(0, 1.7))
p2 <- ggplot(pred_RT_aggcond)+
  geom_area(aes(x=rt, y=dens,fill=interaction(rating, correct), group=interaction(rating, correct)),
            col="black",
            position = "stack", stat = "identity")+
  xlim(c(paramDf$t0,max(Data$rt)))+ylim(c(0, 1.7))
ggarrange(p1, p2, common.legend = TRUE, legend = "bottom")




p1 <- ggplot()+
  geom_density(data=Data, aes(x=rt, fill=interaction(rating, correct), group=interaction(rating, correct), y=..density..),
               position ="stack", bw=0.07)+
  xlim(c(paramDf$t0,quantile(Data$rt, probs = 0.95) ))+ylim(c(0, 16))
p2 <- ggplot(pred_RT_aggcond)+
  geom_area(aes(x=rt, y=densscaled,fill=interaction(rating, correct), group=interaction(rating, correct)),
            col="black",
            position = "stack", stat = "identity")+
  xlim(c(paramDf$t0,quantile(Data$rt, probs = 0.95) ))+ylim(c(0, 16))
ggarrange(p1, p2, common.legend = TRUE, legend = "bottom")







p1 <- ggplot()+
  geom_density(data=simus2, aes(x=rt, fill=interaction(rating, correct), group=interaction(rating, correct), y=..count../(5*nrow(simus2))),
               position ="fill", bw=0.15)+
  xlim(c(paramDf$t0,quantile(simus2$rt, probs = 0.98) ))
p2 <- ggplot(pred_RT_aggcond)+
  geom_area(data=pred_RT_aggcond, aes(x=rt, y=dens,fill=interaction(rating, correct), group=interaction(rating, correct)),
            col="black", position = "fill", stat = "identity")+
  xlim(c(paramDf$t0,quantile(simus2$rt, probs = 0.98) ))
ggarrange(p1, p2, common.legend = TRUE, legend = "bottom")


p1 <- ggplot()+
  geom_density(data=Data, aes(x=rt, fill=interaction(rating, correct), group=interaction(rating, correct), y=..count../(nrow(Data))),
               position ="fill", bw=0.15)+
  xlim(c(paramDf$t0,quantile(Data$rt, probs = 0.98) ))
p2 <- ggplot(pred_RT_aggcond)+
  geom_area(data=pred_RT_aggcond, aes(x=rt, y=dens,fill=interaction(rating, correct), group=interaction(rating, correct)),
            col="black",position = "fill", stat = "identity")+
  xlim(c(paramDf$t0,quantile(Data$rt, probs = 0.98) ))
ggarrange(p1, p2, common.legend = TRUE, legend = "bottom")


ggplot(simus2) +
  geom_density(aes(x=rt, colour="Simus", group=correct, y=..count../nrow(simus2)))+
  geom_line(data=pred_RT_aggcond, aes(x=rt, y=dens, colour="Comp", group=correct))+
  facet_grid(correct~rating)+
  xlim(c(0,quantile(simus2$rt, probs = 0.95) ))
aggSimus <- simus2 %>% group_by(correct, rating, condition) %>%
  summarise(p=n()*5/nrow(simus2))
sum(aggSimus$p)
agg_pred <- pred_conf %>% group_by(rating, correct, condition) %>%
  summarise(p = mean(p)) %>%
  mutate(correct=factor(correct,levels=0:1, labels=c("Wrong", "Correct")))
sum(agg_pred$p)
aggData <- Data %>% group_by(correct, rating, condition) %>%
  summarise(p=n()*5/(nrow(Data))) %>%
  mutate(condition = as.numeric(as.factor(condition)))
sum(aggData$p)
ggplot()+
  geom_bar(data=aggData, aes(x=rating, y=p, fill=correct), stat="identity", position="dodge")+
  geom_point(data=agg_pred, aes(x=rating, y=p, fill=correct, shape="simus"),position = position_dodge(1))+
  geom_point(data=agg_pred, aes(x=rating, y=p, fill=correct, shape="pred"), position = position_dodge(1))+
  facet_grid(.~condition)
