###########################################################################
#####            Comparison dynWEV vs. 2DSD model               #######
###########################################################################

# ? Sebastian Hellmann, 07.04.2021

# 1) Read in data and drop outliers
# 2) fit the models (dynWEV and 2DSD)
# 3) Predict the RT & confidence distribution for the different models
# 4) Plot the predictions together with empirical distributions
# 5) Analyse covariances between parameters


rm(list=ls())


# #library(R.utils)
# library(plyr)
# library(snow)
# library(doSNOW)
# #library(BayesFactor)
# #library(Hmisc)
# #library(effsize)
# #library(drc)
# library(ggplot2)
library(tidyverse)
library(dynWEV)

# 1) Read in data

load("test/dataRausch2018.RData")

## drop "outliers"
Data <- Data %>% group_by(participant)
Ntrials <-  Data %>%
  summarise(Ntot = sum(n()))

Data <- Data %>% filter(rt < mean(rt)+4*sd(rt)  & rt>.3 & Rating1RT>.15)
Ntrials_analysis <- Data %>%
  summarise(Ntot = sum(n()))
### proportion of excluded trials
summary((Ntrials$Ntot-Ntrials_analysis$Ntot)/Ntrials$Ntot)
min(Ntrials_analysis$Ntot)


data <- subset(Data, participant==22)
data <- subset(Data, participant==1)

model = "IRM"
method="ML"
sym_thetas = FALSE
init_grid = NULL
logging=TRUE
nRatings <- 5
opts=list(nAttempts=1, nRestarts=1, maxfun=100)
#source("R/internal_fcts_fitting_RM.R")
optim_method="Nelder-Mead"
optim_method = "bobyqa"
data_names = list()

init_grid <- NULL
grid_search = TRUE
time_scaled = FALSE


#####
minrt <- 0.2
init_grid <- expand.grid(vmin = seq(0.01, 0.8, length.out = 4), ### vmin = drift rate in first condition \in (0,\infty)]
                         vmax = seq(1, 3.8, length.out = 4),     ### vmax = mean drift rate in last condition \in (\vmin,\infty)]
                         a = seq(1,3, length.out = 4),           ### sz = range of possible start points (unif ditr.; in units of a-z) \in [0,1]
                         b = seq(1,3, length.out = 4),           ### sz = range of possible start points (unif ditr.; in units of a-z) \in [0,1]
                         theta0 = seq(0.1, 1,length.out = 3),    ### theta0 = lowest threshold for confidence rating (in difference from threshold / a)
                         thetamax = seq(1.2, 3.5,length.out = 3),### thetamax = highest threshold for confidence rating (in distance from threshold / a)
                         t0 = seq(max(minrt-0.2, 0), max(minrt-0.1, 0)), ### t0 = minimal non-decision time
                         st0 = seq(0.07, 0.15, length.out=3),    ### st0 = range of (uniform dist) non-decision time
                         wrt = seq(0.2, 7, length.out = 5),      ### coeff for time in conf= (b-xj) + (wrt* 1//sqrt(t)) + (wint* (b-xj)/sqrt(t))
                         wint = seq(0.2, 7, length.out = 5))
#

init_grid <- init_grid[sample(1:nrow(init_grid), size=floor(0.05*nrow(init_grid))),]
init_grid <- init_grid[sample(1:nrow(init_grid), size=floor(0.05*nrow(init_grid))),]
init_grid <- init_grid[sample(1:nrow(init_grid), size=floor(0.05*nrow(init_grid))),]

##

###
fitRM(data, model, method, FALSE, sym_thetas, init_grid, grid_search,data_names,nRatings, logging,
       opts = opts, optim_method = optim_method)


model = "PCRMt"
fitRM(data, model, method, FALSE, sym_thetas, init_grid, grid_search,data_names,nRatings, logging,
      opts = opts, optim_method = optim_method)




# inits <- inits[sample(1:nrow(inits), size=floor(0.05*nrow(inits))),]
# inits <- inits[sample(1:nrow(inits), size=floor(0.05*nrow(inits))),]
#
