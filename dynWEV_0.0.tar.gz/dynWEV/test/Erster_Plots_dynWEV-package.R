library(dynWEV)
library(rtdists)
library(tidyverse)

help(d2DSD)

params <- list(th1 = 0.5, th2=1, tau=1, a=1, v=0.7, z=0.5, t0=0, sz=0, sv=0, st0=0, s=1)
list2env(params, envir = environment())
t <- 0.7

d2DSD(t, th1, th2, "upper", tau=tau, a=a, v=v, t0=0, z =z, sv=sv)
d2DSD(t, 2.4, 2.5, "lower", tau=tau, a=a, v=v, t0=0, z =z, sv=sv)


## Test for d2DSD: (change parameters)
tau=seq(0.01, 2, length.out = 100)
test <- Vectorize(d2DSD, "tau")
params <- list(th1 = -1, th2=2, a=1, v=0.7, z=0.5, t0=0, sz=0.2, sv=0.2, st0=0.05, s=1)
list2env(params, envir = environment())
plot(tau, test(0.7, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0,z=z, sv=sv, s=s, sz=sz, st0=st0))
points(0, ddiffusion(0.7, "upper", a=a, v=v, t0=t0, z=z, sv=sv, sz=sz, st0=st0, s=s), col="red", pch="X")

## Test for dWEVd with sv=0:
t00 <- Sys.time()
params <- list(th1 = -1, th2=2, a=1, v=0.7, z=0.5, t0=0, sz=0.2, st0=0.05, s=1, sig=1)
list2env(params, envir = environment())
sv=0
tau=seq(0.01, 4, length.out = 400)
test2 <- Vectorize(dWEVd, "tau")
plot(tau, test2(0.7, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, w=0.2))
points(tau, test2(0.7, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, w=0.1), col="green")
points(tau, test2(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, w=0.6), col="red")
print(difftime(Sys.time(), t00))

### For high w it should be equal to 2DSD
plot(tau, test(0.7, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0,z=z, sv=sv, s=s, sz=sz, st0=st0))
th1 <- th1 - a   #different parametrisation for confidence thresholds
th2 <- th2 - a
points(tau, test2(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,w=0.9999999), col="green")



## Test for dWEVd with sv!=0:
t00 <- Sys.time()
params <- list(th1 = -1, th2=2, a=1, v=0.7, z=0.5, t0=0, sz=0.2, st0=0.05, s=1, sig=1, sv=0.1)
list2env(params, envir = environment())
tau=seq(0.01, 4, length.out = 400)
test2 <- Vectorize(dWEVd, "tau")
plot(tau, test2(0.7, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, w=0.2))
points(tau, test2(0.7, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, w=0.1), col="green")
points(tau, test2(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, w=0.6), col="red")
print(difftime(Sys.time(), t00))

### Compare to 2DSD
params <- list(th1 = -1, th2=2, a=1, v=0.7, z=0.5, t0=0, sz=0.2, st0=0.05, s=1, sig=1, sv=0.1)
list2env(params, envir = environment())
plot(tau, test(0.7, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0,z=z, sv=sv, s=s, sz=sz, st0=st0),
     ylim=c(0,max(test(0.7, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0,z=z, sv=sv, s=s, sz=sz, st0=st0))))
th1 <- th1 - a   #different parametrisation for confidence thresholds
th2 <- th2 - a
points(tau, test2(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,w=0.9999), col="green")

params <- list(th1 = -1, th2=2, a=1, v=0.7, z=0.5, t0=0, sz=0.2, st0=0.05, s=1, sig=1, sv=0.1)
list2env(params, envir = environment())
plot(tau, test(0.7, th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0,z=z, sv=sv, s=s, sz=sz, st0=st0),
     ylim=c(0,max(test(0.7, th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0,z=z, sv=sv, s=s, sz=sz, st0=st0))))
th1 <- th1 - a   #different parametrisation for confidence thresholds
th2 <- th2 - a
points(tau, test2(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,w=0.9999), col="green")
points(tau, test2(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,w=0.9999, c_precision=100), col="orange")



## Steps for the integral in c:
c_steps <- function(w, sig, t, tau, sv, th2, th1) {
  q <- w/(1-w) * tau/(tau+t)
  sig_c <- sig^2/(tau+t) + q^2/(tau)
  sig_plus <- sqrt(sig_c + sv^2*(q+1)^2/(sv^2*t+1))
  sig_minus <- sqrt(sig_c + sv^2*(q-1)^2/(sv^2*t+1))
  diffvths <- ((th2- th1)/(1-w)/(t+tau))^3
  n <- 10^3/(24*sqrt(2*pi)) * diffvths * (1/sig_plus^(5/2) + 1/sig_minus^(5/2))
  n <- 10^3/(24*sqrt(2*pi)) * diffvths * (1/sig_plus + 1/sig_minus)
  return(ceiling(sqrt(n)))
}
c_steps <- Vectorize(c_steps)

c_steps(w=0.99999, sv=0.1, sig=1, t=0.7, th2=2, th1=1, tau=tau)
c_steps(w=0.5, sv=0.1, sig=1, t=0.7, th2=2, th1=1, tau=seq(0.02, 1, length.out = 10))




## Tests for WEVabsmu
params <- list(th1 = -1, th2=2, a=1, v=0.7, z=0.5, t0=0, sz=0.2, st0=0.05, s=1, sig=1, w=0.2, sigmu=1)
list2env(params, envir = environment())
sv=0
t <- 0.7
tau=seq(0.01, 4, length.out = 200)
test3 <- Vectorize(dWEVabsmu, "tau")

plot(tau, test3(t, th1, th2, "upper", tau, a, v, t0, z, d=0, sz=sz, sv=sv, st0=st0, sig=sig, s=1, sigmu=sigmu, w=0.2), ylim=c(0.03, 0.18))
points(tau, test3(t, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.1), col="green")
points(tau, test3(t,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.6), col="red")

sv=1
sigmu=5
th1 = -3
th2 = 5
plot(tau, test3(t, th1, th2, "upper", tau, a, v, t0, z, d=0, sz=sz, sv=sv, st0=st0, sig=sig, s=1, sigmu=sigmu, w=0.2), ylim=c(0.01, 0.1))
points(tau, test3(t, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.1), col="green")
points(tau, test3(t,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.6), col="red")


## Should also be equal to 2DSD if w -> 1
th1 = -3
th2 = 5
plot(tau, test(0.7, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0,z=z, sv=sv, s=s, sz=sz, st0=st0))
th1 <- th1 - a   #different parametrisation for confidence thresholds
th2 <- th2 - a
points(tau, test3(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=1,w=0.999999), col="green") #, c_precision = 100
points(tau, test3(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=1,w=0.9), col="blue") #, c_precision = 100
points(tau, test3(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=1,w=0.7), col="red") #, c_precision = 100
th12 <- -th2
th22 <- -th1
plot(tau, test(0.7, th1=th12, th2=th22, "lower", tau=tau, a=a, v=v, t0=t0,z=z, sv=sv, s=s, sz=sz, st0=st0))
points(tau, test3(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=1,w=0.9999999999), col="green")
points(tau, test3(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=1,w=0.9), col="blue")
points(tau, test3(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=1,w=0.7), col="red")
#points(tau, test3(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=1,w=0.7), col="orange")




##Test of WEVmu
test4 <- Vectorize(dWEVmu, "tau")
params <- list(th1 = -1, th2=2, a=1, v=0.7, z=0.5, t0=0, sz=0.2, st0=0.05, s=1, sig=1, w=0.2, sigmu=1)
list2env(params, envir = environment())
sv=0
t <- 0.7
tau=seq(0.01, 4, length.out = 200)

dWEVmu(0.7, th1, th2, "upper", 1, a, v, t0, z, d=0, sz=sz, sv=sv, st0=st0, sig=sig, s=1, sigmu=sigmu, w=0.2,stop_on_error=TRUE)
plot(tau, test4(t, th1, th2, "upper", tau, a, v, t0, z, d=0, sz=sz, sv=sv, st0=st0, sig=sig, s=1, sigmu=sigmu, w=0.2))
points(tau, test4(t, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.1), col="green")
points(tau, test4(t,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.6), col="red")

sv=1
sigmu=5
th1 = -3
th2 = 5
plot(tau, test4(t, th1, th2, "upper", tau, a, v, t0, z, d=0, sz=sz, sv=sv, st0=st0, sig=sig, s=1, sigmu=sigmu, w=0.2))
points(tau, test4(t, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.1), col="green")
points(tau, test4(t,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.6), col="red")


## Should also be equal to 2DSD if w -> 1
plot(tau, test(0.7, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0,z=z, sv=sv, s=s, sz=sz, st0=st0))
th1 <- th1 - a   #different parametrisation for confidence thresholds
th2 <- th2 - a
points(tau, test4(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,w=0.999999), col="green")
points(tau, test4(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,w=0.9), col="blue")
points(tau, test4(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,w=0.7), col="red")

th12 <- -th2
th22 <- -th1
plot(tau, test(0.7, th1=th12, th2=th22, "lower", tau=tau, a=a, v=v, t0=t0,z=z, sv=sv, s=s, sz=sz, st0=st0))
points(tau, test4(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,w=0.9999), col="green")
points(tau, test4(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,w=0.9), col="blue")
points(tau, test4(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,w=0.7), col="red")




#### Test for high w with sv=0
### WEVabsmu
sv=0
sigmu=1
th1 = -3
th2 = 5
tau=seq(0.01, 8, length.out = 400)
plot(tau, test(0.7, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0,z=z, sv=sv, s=s, sz=sz, st0=st0))
th1 <- th1 - a   #different parametrisation for confidence thresholds
th2 <- th2 - a
points(tau, test3(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=1,w=0.999999), col="green")
points(tau, test3(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=1,w=0.9), col="blue")
points(tau, test3(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=1,w=0.7), col="red")
th12 <- -th2
th22 <- -th1
plot(tau, test(0.7, th1=th12, th2=th22, "lower", tau=tau, a=a, v=v, t0=t0,z=z, sv=sv, s=s, sz=sz, st0=st0))
points(tau, test3(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=1,w=0.9999999999), col="green")
points(tau, test3(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=1,w=0.9), col="blue")
points(tau, test3(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=1,w=0.7), col="red")

plot(tau, test(0.7, th1=th12, th2=th22, "lower", tau=tau, a=a, v=v, t0=t0,z=z, sv=sv, s=s, sz=sz, st0=st0))
points(tau, test3(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=0,w=0.9999999999), col="green")
points(tau, test3(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=0,w=0.9), col="blue")
points(tau, test3(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=0,w=0.7), col="red")


### WEVmu
sv=0
sigmu=1
th1 = -3
th2 = 5

plot(tau, test(0.7, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0,z=z, sv=sv, s=s, sz=sz, st0=st0))
th1 <- th1 - a   #different parametrisation for confidence thresholds
th2 <- th2 - a
points(tau, test4(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,w=0.999999), col="green")
points(tau, test4(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,w=0.9), col="blue")
points(tau, test4(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,w=0.7), col="red")

th12 <- -th2
th22 <- -th1
plot(tau, test(0.7, th1=th12, th2=th22, "lower", tau=tau, a=a, v=v, t0=t0,z=z, sv=sv, s=s, sz=sz, st0=st0))
points(tau, test4(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,w=0.999), col="green")
points(tau, test4(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,w=0.9), col="blue")
points(tau, test4(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,w=0.7), col="red")



### Test "lower" responses for WEVabsmu/3
plot(tau, test4(t, th1, th2, "lower", tau, a, v, t0, z, d=0, sz=sz, sv=sv, st0=st0, sig=sig, s=1, sigmu=sigmu, w=0.2), ylim=c(0.035,0.14))
points(tau, test4(t, th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.1), col="green")
points(tau, test4(t,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.6), col="red")
points(tau, test4(t, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.1), col="green", type="l")
points(tau, test4(t,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.6), col="red", type="l")



plot(tau, test3(t, th1, th2, "lower", tau, a, v, t0, z, d=0, sz=sz, sv=sv, st0=st0, sig=sig, s=1, sigmu=sigmu, w=0.2), ylim=c(0.037,0.134))
points(tau, test3(t, th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.1), col="green")
points(tau, test3(t,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.6), col="red")
points(tau, test3(t, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.1), col="green", type="l")
points(tau, test3(t,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.6), col="red", type="l")




## Test of WEVabsmu with sigmu = 0 (should be equal to WEVmu)
##
params <- list(th1 = -1, th2=2, a=1, v=0.7, z=0.5, t0=0, sz=0.2, st0=0.05, s=1, sig=1, w=0.2, sigmu=0)
list2env(params, envir = environment())
sv=0
t <- 0.7
tau=seq(0.01, 4, length.out = 200)

plot(tau, test4(t, th1, th2, "upper", tau, a, v, t0, z, d=0, sz=sz, sv=sv, st0=st0, sig=sig, s=1, sigmu=sigmu, w=0.2))
points(tau, test4(t, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.1), col="green")
points(tau, test4(t,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.6), col="red")
points(tau, test3(t, th1, th2, "upper", tau, a, v, t0, z, d=0, sz=sz, sv=sv, st0=st0, sig=sig, s=1, sigmu=sigmu, w=0.2), type="l")
points(tau, test4(t, th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.1), col="green", type="l")
points(tau, test4(t,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz, sigmu=sigmu, w=0.6), col="red", type="l")




## Check time difference between sigmu =0 and sigmu != 0 for WEVabsmu
sv=0
sigmu=2
th1 = -3
th2 = 5
tau=seq(0.01, 8, length.out = 800)
times <- c()

t00 <- Sys.time()
plot(tau, test3(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=sigmu,w=0.5),ylim=c(0,0.14), type="l", lty=2)
times[1] <- difftime(Sys.time(), t00, units = "sec")

t00 <- Sys.time()
points(tau, test3(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=sigmu,w=0.999999), col="green", type="l", lty=2)
times[2] <- difftime(Sys.time(), t00, units = "sec")

t00 <- Sys.time()
points(tau, test3(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=sigmu,w=0.5), col="red", type="l", lty=2)
times[3] <- difftime(Sys.time(), t00, units = "sec")

t00 <- Sys.time()
points(tau, test3(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=sigmu,w=0.999999), col="blue", type="l", lty=2)
times[4] <- difftime(Sys.time(), t00, units = "sec")

sigmu = 0

t00 <- Sys.time()
points(tau, test3(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=sigmu,w=0.5), type="l")
times[5] <- difftime(Sys.time(), t00, units = "sec")

t00 <- Sys.time()
points(tau, test3(0.7,  th1=th1, th2=th2, "upper", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=sigmu,w=0.999999), col="green", type="l")
times[6] <- difftime(Sys.time(), t00, units = "sec")

t00 <- Sys.time()
points(tau, test3(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=sigmu,w=0.5), col="red", type="l")
times[7] <- difftime(Sys.time(), t00, units = "sec")

t00 <- Sys.time()
points(tau, test3(0.7,  th1=th1, th2=th2, "lower", tau=tau, a=a, v=v, t0=t0, z =z, sv=sv,sig=sig, s=1,st0=st0,sz=sz,sigmu=sigmu,w=0.999999), col="blue", type="l")
times[8] <- difftime(Sys.time(), t00, units = "sec")
times <- matrix(times, nrow=2, byrow = TRUE)
times

