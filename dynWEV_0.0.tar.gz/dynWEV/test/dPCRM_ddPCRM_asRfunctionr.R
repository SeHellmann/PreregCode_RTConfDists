library(gsl) ## for error function
library(dynWEV)
library(tidyverse)

paramDf <- structure(list(mu1 = 1.5, mu2 = 0.5, a = 2.5, b = 2.5, s = 1,
                          t0 = 0.1, st0 = 0.5, th1 = 0, th2 = 20000, wx = 4.1, wint = 4.123,
                          wrt = 5), row.names = c(NA, -1L), class = "data.frame")
resp <- 1
integrand <- function(t) {
  dIRM(t,resp,  paramDf)
}

Ints <- integrate(integrand, lower = paramDf$t0, upper = 15, subdivisions = 800)$value #+


rts <- c(1.2917210, 0.4016822, 2.1817598, 0.5011523, 2.0822897, 0.6708186, 1.9126234,
         0.8956473, 1.6877947, 1.1556669, 1.4277751, 0.3818046, 2.2016374, 0.4416638,
         2.1417782, 0.5781432, 2.0052988, 0.7774256, 1.8060165, 1.0226797, 1.5607623)
dIRM(rts,resp,  paramDf)
rts[12]
dIRM(rts[12]-1e-5,2,  paramDf)
dIRM(rts[12]+1e-5,2,  paramDf)

paramDf$t0
min(rts)
# rts <- seq(0, rts[12], length.out=700)
# dIRM(rts,resp,  paramDf)




inv_sqrt_2pi = 0.3989422804014327;

length = length(rts);
out <- rep(0,length);
win <- resp
params <- paramDf
muw = params[['mu1']];
mul = params[['mu2']];
a = params[['a']];
b = params[['b']];
sigma = params[['s']];
th1 = params[['th1']];
th2 = params[['th2']];
st0 = params[['st0']];
wx = params[['wx']];
wrt = params[['wrt']];
wint = params[['wint']];
rts <- rts- params[['t0']]




t=0.5
x2 = 0.2

g <- Vectorize(function(t, x2,win, params) {
  a <- if_else(win ==1, -params$a, -params$b)
  b <- if_else(win ==2, -params$a, -params$b)
  muw <- if_else(win==1, params$mu1, params$mu2)
  mul <- if_else(win==2, params$mu1, params$mu2)

  x2 <- x2 + b

  fac = 1/(sqrt(3)*4*pi);
  C = c(1, -1, -1, 1,1, -1);
  expC1 = c(0, a, 0, a, a+b, a+b);
  expC2 = c(0, 0, b, a+b, b, a+b);

  expC = -2 * (muw*expC1 + mul*expC2);


  Xis = matrix(c(a, -a, a+b, b, -a-b, -b,
                 b, a+b, -b, -a-b, a, -a), nrow = 6, ncol=2);
  sig2t = 2*t;
  x1tilde = -Xis[,1]-muw*t;
  x2tilde = x2 - Xis[,2] - mul*t
  1/(3*sqrt(3)*pi*t^2) * sum(C*((-Xis[,1]-muw*t)*2+(x2 - Xis[,2] - mul*t))*
                               exp(expC - (Xis[,1]+muw*t)^2/(2*t) -
                               ((-Xis[,1]-muw*t)/2+(x2 - Xis[,2] - mul*t))^2/(3/2*t)))
}, vectorize.args = c("t", "x2"))

g(1, x2, win, params)
ddPCRM(1, win, x2, params = params)

plot(seq(-3, 3, by =0.01), g(0.5, seq(-3, 3, by =0.01), win = win, params =params))
points(seq(-3, 3, by =0.01), ddPCRM(0.5, win, seq(-3, 3, by =0.01), params =params), col="red", type="l")
plot(seq(2.4, 3, by =0.01), g(0.5, seq(2.4, 3, by =0.01), win = win, params =params))
plot(seq(-3, 6, by =0.01), g(0.5, seq(-3, 6, by =0.01), win = win, params =params))


plot(seq(-20000, 0, by =3), g(0.5, seq(-20000, 0, by =3), win = win, params =params))


integrate(function(xj) ddPCRM(1, win, xj, params), lower=-20000, upper=0)
integrate(function(xj) ddPCRM(1, win, xj, params), lower=-50, upper=0)


int_g <- Vectorize(function(t, win, params) {
  integrate(function(x2) g(t, x2, win, params), lower=params$th1, upper=params$th2,
            stop.on.error = FALSE)$value
}, vectorize.args = "t")
params$th1 = -2000
params$th2 = 0
int_g(1, win, params)






fac_errf = 2.170803763674803;   ### sqrt(M_PI*3/2); used in densPCRM
densPCRM <- function(t, win, params){
  a <- if_else(win ==1, -params$a, -params$b)
  b <- if_else(win ==2, -params$a, -params$b)
  muw <- if_else(win==1, params$mu1, params$mu2)
  mul <- if_else(win==2, params$mu1, params$mu2)

  th2 <- params$th2+b
  th1 <- params$th1+b
  sig2t = 2*t;
  fac = 1/(sqrt(3)*4*pi);
  C = c(1, -1, -1, 1,1, -1);
  expC1 = c(0, a, 0, a, a+b, a+b);
  expC2 = c(0, 0, b, a+b, b, a+b);

  expC = -2 * (muw*expC1 + mul*expC2);


  Xis = matrix(c(a, -a, a+b, b, -a-b, -b,
                 b, a+b, -b, -a-b, a, -a), nrow = 6, ncol=2);

  # tth1 = (-th2*sqrt(t) + wrt)/(sqrt(t)*wx + wint);
  # tth2 = (-th1*sqrt(t) + wrt)/(sqrt(t)*wx + wint);
  tth2 <- th2
  tth1 <- th1
  temp = 0;
  for (j in 1:6) {
    num_erfn2 = tth2 - Xis[j,2] - mul*t - (Xis[j,1]+muw*t)/2;
    num_erfn1 = tth1 - Xis[j,2] - mul*t - (Xis[j,1]+muw*t)/2;
    den_phi = sig2t * 0.75;
    temp = temp + C[j]* exp(expC[j] - (Xis[j, 1]+muw*t)*(Xis[j, 1]+muw*t)/(sig2t)) *
      (fac_errf/sqrt(t)* (- (Xis[j,1]+muw*t)) * (erf(num_erfn2/sqrt(den_phi)) - erf(num_erfn1/sqrt(den_phi))) -
         (exp(-num_erfn2*num_erfn2/den_phi) - exp(-num_erfn1*num_erfn1/den_phi)));
  }

  res = temp/(4*sqrt(3)*pi*t);
  return(res);
}




densPCRM(t, win, params)
int_g(t, win, params)
win<- 2
densPCRM(t, win, params)
int_g(t, win, params)

params$th2 <- params$a
integrate(Vectorize(function(t) return(int_g(t, win, params))), lower=0.01, upper=30)
integrate(function(t) return(densPCRM(t, win, params)), lower=0, upper=30)
win <- 1
integrate(Vectorize(function(t) return(int_g(t, win, params))), lower=0.01, upper=30)
integrate(function(t) return(densPCRM(t, win, params)), lower=0, upper=30)


T <- seq(0.01, 5, length.out=50)
plot(T, int_g(T, 1, params), type="l")
points(T, densPCRM(T, 1, params), type="l", col="red")
points(T, int_g(T, 2, params), type="l")
points(T, densPCRM(T, 2, params), type="l", col="red")




library(cubature)
adaptIntegrate(function(X) ddPCRM(X[1], 1, X[2], params), lower=c(0, -Inf), upper=c(30, paramDf$b))
adaptIntegrate(function(X) ddPCRM(X[1], 2, X[2], params), lower=c(0, -Inf), upper=c(30, paramDf$a))




params <- list("mu1"=rnorm(1, 0, 1),
            "mu2" = rnorm(1,0, 1),
            "a" = rchisq(1, 2),
            "b" = rchisq(1, 2),
            "th1" = -rchisq(1, 3))
params$th2 <- runif(1, params$th1, min(params$a, params$b))
as.data.frame(params)
T <- seq(0.1, 1.3, length.out=5)
int_g(T, 1, params)
densPCRM(T, 1, params)

int_g(T, 2, params)
densPCRM(T, 2, params)
T <- seq(0.01, 5, length.out=20)
plot(T, int_g(T, 1, params), type="l")
points(T, densPCRM(T, 1, params), type="l", col="red")
points(T, int_g(T, 2, params), type="l")
points(T, densPCRM(T, 2, params), type="l", col="red")








###########################################################################
#######    Now try to use confidence variable instead of x2      ##########
###########################################################################
wrt <- 0.1
t <- 0.001
wx <- 1
wint <- 1
conf <- 100  ## conf > wrt/sqrt(t)

x2 <- -(conf*sqrt(t) - wrt)/(sqrt(t)*wx+wint)
x2
#   conf = -wx*x2 + wrt/sqrt(t) - wint*x2/sqrt(t)
-wx*x2 + wrt/sqrt(t) - wint*x2/sqrt(t)

t  = wrt/sqrt(t)
b = (wx+wint/sqrt(t))
x = -seq(0.001, 2, length.out=20)   ## -x2
plot(x, y=x*b+t, xlim=c(min(x*b+t,x,  0), max(x*b+t,x, 2)), ylim=c(min(x*b+t,x,  0), max(x*b+t,x, 2)))
abline(a=0, b=1)
points(x=(x*b+t), y=((x*b+t)-t)/b, col="red")

conf <- seq(wrt/sqrt(t)+0.001, wrt/sqrt(t)*2, length.out=20)  ## conf > wrt/sqrt(t)
x2 <- -(conf*sqrt(t) - wrt)/(sqrt(t)*wx+wint)
plot(conf, x2, xlim=c( min(conf, x2), max(conf, x2)), cex=x2/min(x2), ylim=c(min(conf, x2), max(conf, x2)))
abline(a=0, b=1)
points(x=x2, y=-wx*x2 + wrt/sqrt(t) - wint*x2/sqrt(t),cex=x2/min(x2), col="red")

x2 <- seq(0.001, 2, length.out=20)
conf <- wx*x2 + wrt/sqrt(t)  + wint*x2/sqrt(t) ## conf > wrt/sqrt(t)
plot(x2, conf, xlim=c(0, max(conf, x2)),cex=x2,  ylim=c(0, max(conf, x2)))
abline(a=0, b=1)
points(x=conf, y=(conf*sqrt(t) - wrt)/(sqrt(t)*wx+wint),cex=x2, col="red")





paramDf <- structure(list(mu1 = 1.5, mu2 = 0.5, a = 1.5, b = 1.5, s = 1,
                          t0 = 0, st0 = 0, th1 = 0, th2 = 20000, wx = 1.1, wint = 1.123,
                          wrt = 1), row.names = c(NA, -1L), class = "data.frame")
g_conf <- function(t, conf, win, paramDf) {
  dist_x2 <- -(conf*sqrt(t) - wrt)/(sqrt(t)*wx+wint)
  x2 <- dist_x2 + if_else(win==1, paramDf$b, paramDf$a)
  print(x2)
  g(t, x2, win, paramDf)
}
g_conf(0.5, 1, 1, paramDf)
conf <- seq(paramDf$wrt/sqrt(0.5)+0.0000001, paramDf$wrt/sqrt(0.5)+0.21, length.out=100)
plot(conf, g_conf(0.5, conf, 1, paramDf))

conf <- seq(0, 1.7, length.out=120)
plot(conf, g_conf(0.5, conf, 1, paramDf))

conf <- seq(0, 0.17, length.out=120)
plot(conf, g_conf(0.5, conf, 1, paramDf))
