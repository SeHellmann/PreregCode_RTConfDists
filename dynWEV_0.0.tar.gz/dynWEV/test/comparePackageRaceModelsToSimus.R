### Here, I simulate and test the correctness of the 2DSD implementation in the package WITHOUT intertrial variability
### I.e. in the Ratcliff model, set sv=0, st0=0 and sv=0.
# 1. Simulate the model and confidence outcomes and Aggregate Rating Distribution####
# 2. Compute the distribution of confidence judgements with my own methods  ####
# 3. compute the rating distribution and the density of RT on observed range and the conf distribution with my package   ####
# 4. Plot the distributions of simulations and the package together ####
########################

library(dynWEV)
library(tidyverse)
nConds <- 5
nRatings <- 5
time_scaled=TRUE
minrt=0.2
sym_thetas=FALSE
optim_method = "bobyqa"
init_grid = NULL

source("R/internal_fcts_fitting_RM.R")
inits <- create_grid_RM(init_grid, nConds, nRatings, time_scaled, optim_method, minrt, sym_thetas)


p <- inits[sample(1:nrow(inits),1 ), ]
paramDf <- p
pnames <- names(paramDf)
if (nRatings > 2) {
  if (sym_thetas) {
    paramDf[paste("theta", 2:(nRatings-1))] <- c(t(paramDf['theta1'])) + c(t(cumsum(paramDf[grep(pnames, pattern = "dtheta", value=TRUE)])))
  } else {
    paramDf[paste("thetaUpper", 2:(nRatings-1), sep="")] <- c(t(paramDf['thetaUpper1'])) + cumsum(c(t(paramDf[grep(pnames, pattern = "dthetaUpper", value=TRUE)])))
    paramDf[paste("thetaLower", 2:(nRatings-1), sep="")] <- c(t(paramDf['thetaLower1'])) + cumsum(c(t(paramDf[grep(pnames, pattern = "dthetaLower", value=TRUE)])))
  }
  paramDf <- paramDf[ -grep(names(paramDf), pattern="dtheta")]
}
if (!is.data.frame(paramDf)) {
  paramDf2 <-   data.frame(matrix(nrow=1, ncol=length(paramDf)))
  paramDf2[1,] <- paramDf
  names(paramDf2) <- names(paramDf)
  paramDf <- paramDf2
}
if (!time_scaled) {
  paramDf$wx <- 1
  paramDf$wrt <- 0
  paramDf$wint <- 0
} else {
  paramDf$wx <- 1/(paramDf$wrt+paramDf$wint+1)
  paramDf$wrt <- paramDf$wrt/(paramDf$wrt+paramDf$wint+1)
  paramDf$wint <- paramDf$wint/(paramDf$wrt+paramDf$wint+1)
}

n <- 10000
simus <- rRM(paramDf, n = n, model="PCRMt")
pred <- predictRM_Conf(paramDf, model="PCRMt", maxrt=25, subdivisions=300, .progress = TRUE) %>%
  group_by(condition, rating, correct) %>%
  summarise(p = mean(p))
ggplot(simus)+
  geom_bar(aes(x=rating, y=..count../(2*n)))+
  geom_point(data=pred, aes(x=rating, y=p))+
  facet_grid(cols= vars(correct), rows=vars(condition))









load("E:/AccumModelsMac/newRMt_modelfits_threecoefficients.RData")
#load("../AccumulatorModels/saved_data/fits_RacingModels.RData")
nConds <- 5
nRatings <-5
trimmean <- function(x) {
  x <- x[x<100]
  mean(x)
}
names(fits_RMmodels)
paramDf <- fits_RMmodels %>% group_by(model) %>%
  summarise(across(.cols = 2:22, .fns = trimmean))
paramDf <- fits_RMmodels %>% group_by(model) %>%
  summarise(cur_data_all()[sample(1:nrow(cur_data()), 1),2:22])
paramDf
# 1. Simulate the model and confidence outcomes and Aggregate Rating Distribution####
n <- 10^4
## Simulations

simus <- paramDf %>% group_by(model) %>%
  summarise(rRM(cur_data(), n = n, model = .data$model, time_scaled = FALSE, gamma = FALSE, agg_simus = FALSE))
pred <- paramDf %>% group_by(model) %>%
  summarise(predictRM_Conf(cur_data(), model=.data$model, maxrt=25, subdivisions=500, .progress = TRUE)) %>%
  group_by(model, condition, rating, correct) %>%
  summarise(p = mean(p))

ggplot()+
  geom_bar(data=subset(simus, model=="PCRMt"), aes(x=rating, y=..count../(2*n)))+
  geom_point(data=subset(pred, model=="PCRMt"), aes(x=rating, y=p))+
  facet_grid(cols= vars(correct), rows=vars(condition))

ggplot()+
  geom_bar(data=subset(simus, model=="IRMt"), aes(x=rating, y=..count../(2*n)))+
  geom_point(data=subset(pred, model=="IRMt"), aes(x=rating, y=p))+
  facet_grid(cols= vars(correct), rows=vars(condition))


pred %>% group_by(model, condition) %>%
  summarise(p = sum(p))


rt <- seq(0, 3.5, length.out=400)
params <- subset(paramDf, model=="PCRMt")
params$mu1 <- params$v3
params$mu2 <- -params$v3
params$th1 <- 0
params$th2 <- params$thetaUpper1
dens <- dPCRM(rt, response=1, params)
plot(rt, dens)

params$mu1 <- params$v3
params$mu2 <- -params$v3
params$th1 <- 0
params$th2 <- params$thetaUpper1
integrate(function(rt) dPCRM(rt, response=1, params), 0, Inf,
          rel.tol = 1e-12)
params[,c("th1", "th2")] <- t(c(0, params$thetaLower1))

integrate(function(rt) dPCRM(rt, response=2, params), 0, Inf,
          rel.tol = 1e-12)
params[,c("mu1", "mu2", "th1", "th2")] <- t(c(-params$v3, params$v3,0, params$thetaUpper1))
integrate(function(rt) dPCRM(rt, response=1, params), 0, Inf,
          rel.tol = 1e-12)
params[,c("th1", "th2")] <- t(c(0, params$thetaLower1))
integrate(function(rt) dPCRM(rt, response=2, params), 0, Inf,
          rel.tol = 1e-12)



filter(pred, model=="PCRMt" & condition==3 & rating==1)

for ( i in 1:40) {
  params[paste0("v", i)] <- -1 +( 3/10*i)^2
}

pred <- params %>%
  summarise(predictRM_Conf(cur_data(), model=.data$model, maxrt=25, subdivisions=500, .progress = TRUE)) %>%
  group_by(condition, rating, correct) %>%
  summarise(p = mean(p))
sum_int <- pred %>% group_by(condition) %>%
  summarise(p = sum(p)) %>%
  mutate(v=c(t(params[paste0("v", 1:40)])))
ggplot(sum_int) +
  geom_point(aes(x=v, y=p))


## Around 0:
for ( i in 1:20) {
  params[paste0("v", i)] <- -0.2+ (0.4/20*i)
}

pred <- params %>% select(-paste0("v", 21:40)) %>%
  summarise(predictRM_Conf(cur_data(), model=.data$model, maxrt=25, subdivisions=500, .progress = TRUE)) %>%
  group_by(condition, rating, correct) %>%
  summarise(p = mean(p))
sum_int <- pred %>% group_by(condition) %>%
  summarise(p = sum(p)) %>%
  mutate(v=c(t(params[paste0("v", 1:20)])))
ggplot(sum_int) +
  geom_point(aes(x=v, y=p))
