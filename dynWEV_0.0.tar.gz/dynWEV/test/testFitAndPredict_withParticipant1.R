#########   Script to test the fitting function the 2DSD and WEV models    ######
#########                                                                  ######
#########     Data taken from Rausch 2018, Exp2                            ######

# ? Sebastian Hellmann, 10.03.2021
cat("\014")
rm(list=ls())
library(dynWEV)
# 1) Read in data
load("test/dataRausch2018.RData")
Data <- subset(Data, rt > .2 & rt <= 5.5)
data <- subset(Data, participant==1)
nrow(data)
head(data)


init_grid <- expand.grid(a = c(1.7),
                         vmin = c(0.01, 1),
                         vmax = c(2.5),
                         sv = c(0.01),
                         z = c(0.5),
                         sz = c(0.1),
                         t0 = min(data$rt)-0.05,
                         st0 = c(0.1),
                         theta0 = c(1.5),
                         thetamax = c(3),
                         tau = c(0.2, 0.8),
                         sig = 1,
                         w = 0.5,
                         sigmu = 0.1)
fitsWEVmu <- fitWEV(data, "WEVmu", "ML", 1, FALSE, init_grid = init_grid,
               opts = list(nAttempts=2, nRestarts=1, maxit=200, reltol=1e-3), logging = TRUE)
### Test with renamed columns
data <- rename(data, SOA=condition,
               confidence = rating, stimulus=response, response=stimulus)
fitWEV(data, "WEVmu", "ML", 1, FALSE, init_grid=init_grid,
       opts = list(nAttempts=2, nRestarts=1, maxit=200, reltol=1e-3), logging = TRUE,
       condition="SOA", rating="confidence")



init_grid <- expand.grid(a = c(1.7, 2.5),
                         vmin = c(0.01, 1),
                         vmax = c(2.5, 3),
                         sv = c(0.01, 0.3),
                         z = c(0.5),
                         sz = c(0.1),
                         t0 = min(data$rt)-0.05,
                         st0 = c(0.1, 0.8),
                         theta0 = c(0.5, 1.5),
                         thetamax = c(2,3),
                         tau = c(0.2, 0.8))
fits2DSD <- fitWEV(data, "2DSD", "ML", 1, FALSE, init_grid = init_grid,
               opts = list(nAttempts=5, nRestarts=3, maxit=200, reltol=1e-3), logging = TRUE)
fitstestparallel <- fitWEV(data, "2DSD", "ML", 1, FALSE, init_grid = init_grid,
                           nRatings=5,
                           opts = list(nAttempts=2, nRestarts=2, maxfun=200, reltol=1e-3), logging = TRUE, useparallel = TRUE)


init_grid <- expand.grid(a = c(1.7),
                         vmin = c(0.01),
                         vmax = c(2.5),
                         sv = c(0.01),
                         z = c(0.5),
                         sz = c(0.1),
                         t0 = min(data$rt)-0.05,
                         st0 = c(0.1),
                         theta0 = c(1.5),
                         thetamax = c(3),
                         tau = c(0.2, 0.8),
                         sig = 1,
                         w = c(0.3,0.7),
                         sigmu = 0.1)
fitsWEVd <- fitWEV(data, "WEVd", "ML", 1, FALSE, init_grid = init_grid,
               opts = list(nAttempts=1, nRestarts=3, maxit=500, reltol=1e-3), logging = TRUE)


init_grid <- expand.grid(a = c(1.7),
                         vmin = c(0.01),
                         vmax = c(2.5),
                         sv = c(0.01),
                         z = c(0.5),
                         sz = c(0.1),
                         t0 = min(data$rt)-0.05,
                         st0 = c(0.1),
                         theta0 = c(1.5),
                         thetamax = c(3),
                         tau = c(0.2, 0.8),
                         sig = 1,
                         w = c(0.5),
                         sigmu = 0.1, 1)
fitsWEVabsmu <- fitWEV(data, "WEVabsmu", "ML", 1, FALSE, init_grid = init_grid,
                   opts = list(nAttempts=2, nRestarts=1, maxit=200, reltol=1e-3), logging = TRUE)


predWEVabsmu <- predictDistWEV_Conf(paramDf = fitsWEVabsmu, model="WEVabsmu")
predWEVmu <- predictDistWEV_Conf(paramDf = fitsWEVmu, model="WEVmu")
predWEVd <- predictDistWEV_Conf(paramDf = fitsWEVd, model="WEVd")
pred2DSD <- predictDistWEV_Conf(paramDf = fits2DSD, model="2DSD")

save.image(file="test/fitsANDpredictions_part1.RData")





### test renaming
###
p <- structure(list(a = 1.7, z = 0.5, sz = 0.1, v1 = 0.1, v2 = 0.7,
               v3 = 1.3, v4 = 1.9, v5 = 2.5, st0 = 0.1, sv = 0.01, t0 = 0,
               thetaLower1 = 0.8, dthetaLower2 = 0.9, dthetaLower3 = 0.9,
               dthetaLower4 = 0.9, thetaUpper1 = 0.8, dthetaUpper2 = 0.9,
               dthetaUpper3 = 0.9, dthetaUpper4 = 0.9, tau = 0.3, w = 0.3,
               sig = 0.5, sigmu = 0), row.names = 200L, class = "data.frame")


