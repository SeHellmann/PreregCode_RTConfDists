### Here, I simulate and test the correctness of the 2DSD implementation in the package WITHOUT intertrial variability
### I.e. in the Ratcliff model, set sv=0, st0=0 and sv=0.
# 1. Simulate the model and confidence outcomes and Aggregate Rating Distribution####
# 2. Compute the distribution of confidence judgements with my own methods  ####
# 3. compute the rating distribution and the density of RT on observed range and the conf distribution with my package   ####
# 4. Plot the distributions of simulations and the package together ####
########################



# 0. Load packages and set parameter set:
cat("\014")
rm(list=ls())
library(tidyverse)
library(dynWEV)


#######  Oder dis:
paramDf <- structure(list(participant = 25, model = "PCRM", a = 0.754173365669477,
                          b = 0.885015280000596, s = 0.935375502273285, t0 = 0.377835741372225,
                          st0 = 1.00034222556902e-06, w = NA_real_, v1 = 0.211074714013138,
                          v2 = 0.546526873764818, v3 = 0.883796822634184, v4 = 1.51362111374615,
                          v5 = 1.96998252036351, thetaLower1 = 1.28448464781263, thetaLower2 = 1.32285824361175,
                          thetaLower3 = 1.37172296657712, thetaLower4 = 1.40906754547749,
                          thetaUpper1 = 1.4332828935809, thetaUpper2 = 1.44143259791258,
                          thetaUpper3 = 1.47176339655705, thetaUpper4 = 1.53636227418947,
                          negLogLik = 414.240667581854, N = 535L, k = 18L, BIC = 941.562136607836,
                          AICc = 865.667381675336, AIC = 864.481335163708), row.names = 91L, class = "data.frame")

nConds = 5
nRatings = 5
#######



# 1. Simulate the model and confidence outcomes and Aggregate Rating Distribution####
n <- 10^4
## Simulations
simus <- paramDf %>% group_by(model) %>%
  summarise(rRM(cur_data(), n = n, model = .data$model, time_scaled = FALSE, gamma = FALSE, agg_simus = FALSE))

simus_dist <- simus %>% filter(response !=0) %>%
  group_by(correct,response, rating, stimulus, model, condition) %>%
  summarise(p = n()/(n)) %>%
  full_join(y=expand.grid(correct=c(0,1), stimulus=1:2,
                          condition = 1:nConds,rating = 1:nRatings,
                          response=1:2,
                          model=c("PCRM"))) %>%
  mutate(p = ifelse(is.na(p), 0, p))
simus_dist %>% group_by(condition, stimulus) %>% summarise(p=sum(p))

## Aggregate Rating Distribution
Agg_RatingDist_Simus <- simus %>% filter(response !=0) %>%
  group_by(correct,response, rating, model, condition) %>%
  summarise(p = n()/(n)) %>%
  full_join(y=expand.grid(correct=c(0,1),
                          condition = 1:nConds,rating = 1:nRatings,
                          response=1:2,
                          model=c("PCRM"))) %>%
  mutate(p = ifelse(is.na(p), 0, p))
sum(Agg_RatingDist_Simus$p)
Agg_RatingDist_Simus %>% group_by(condition, model) %>% summarise(p=sum(p))


# 3. Predict the rating distribution with my package   ####
## Rating Distribution
preds_pckg <- paramDf %>% group_by(model) %>%
  summarise(predictRM_Conf(cur_data(),model=cur_data_all()$model[1], time_scaled=FALSE,.progress = TRUE,
                           maxrt=30, subdivisions = 500))
preds_pckg %>% group_by(condition, stimulus) %>% summarise(p=sum(p))
preds_pckg <- mutate(preds_pckg, p=p)
temp <- subset(preds_pckg, condition ==1)
sum(temp$p + temp$err)


preds_RT <- paramDf %>% group_by(model) %>%
  summarise(predictRM_RT(cur_data(), model=cur_data_all()$model[1], time_scaled = FALSE, .progress = TRUE,
                         maxrt = max(simus$rt), minrt=paramDf$t0+0.00001, subdivisions = 300, scaled=TRUE,
                         DistConf = subset(preds_pckg, model==cur_data_all()$model[1])))
Agg_preds_RT  <- preds_RT %>% group_by(model, rt, rating, condition, correct) %>%
  summarise(dens=mean(dens, na.rm=TRUE), densscaled=mean(densscaled, na.rm=TRUE))


# 4. Plot the distributions of simulations and the package together ####
p <- ggplot(data=simus_dist, aes(y=p, x=rating, fill=as.factor(response)))+
  geom_bar(position="dodge", stat = "identity")+
  geom_point(data=mutate(preds_pckg, p=p),
             aes(shape="package"), position=position_dodge(1), col="black")+
  facet_grid(rows = vars(condition), cols=vars(stimulus))
p



p <- ggplot(data=Agg_RatingDist_Simus, aes(x=rating, y=p, fill=as.factor(correct)))+
  geom_bar(position="dodge", stat = "identity")+
  geom_point(data=summarise(group_by(preds_pckg, rating, correct, condition), p=mean(p)),
             aes(shape="package"), position=position_dodge(1), col="black")+
  facet_grid(rows = vars(condition))
p


simus2 <- simus %>% filter(rt<5)
dscaledplot <- ggplot()+
  geom_density(data=simus2, aes(x=rt, y=..density.., col=as.factor(correct), lty="simus"))+
  geom_line(data=Agg_preds_RT, aes(x=rt, y=densscaled, col=as.factor(correct), lty="comp"))+
  facet_grid(rows=vars(condition), cols = vars(model), labeller = labeller(response=label_value, rating=label_both))+
  xlim(c(0,5))
dscaledplot

#### Examination of density irregularities
ggplot(preds_RT, aes(x=rt, y=dens, col=as.factor(rating), linetype=as.factor(response),
                     group=interaction(rating, response)))+
  geom_line(size=1.3)+
  facet_grid(rows=vars(condition), cols=vars(stimulus))


dplot <- ggplot()+
  geom_density(data=simus2, aes(x=rt, y=..count../(2*nConds*n), group=interaction(rating, correct),
                                lty=as.factor(correct), col="simus"))+
  geom_line(data=Agg_preds_RT, aes(x=rt, y=dens, lty=as.factor(correct), col="comp"))+
  facet_grid(rows=vars(condition), cols = vars(rating), labeller = labeller(response=label_value, rating=label_both),
             scales = "free")+
  xlim(c(0.35,2.3))
dplot

dplot <- ggplot()+
  geom_density(data=simus2, aes(x=rt, y=..density.., col=as.factor(correct), lty="simus"), bw=0.12)+
  geom_line(data=Agg_preds_RT, aes(x=rt, y=densscaled, col=as.factor(correct), lty="comp"))+
  facet_grid(rows=vars(condition), cols = vars(model), labeller = labeller(response=label_value, rating=label_both))+
  xlim(c(0,5))
dplot


# ggplot()+
#   geom_line(data=df, aes(x=rt, y=dens, col=response, lty="comp"), size=1.1)+
#   facet_grid(rows=vars(response), cols = vars(rating))

save.image(file="package_test/test_WEV/TSDSDT_samplesNcomputattions.RData")

