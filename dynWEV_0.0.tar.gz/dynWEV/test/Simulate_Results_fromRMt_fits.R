### Here, I simulate and test the correctness of the 2DSD implementation in the package WITHOUT intertrial variability
### I.e. in the Ratcliff model, set sv=0, st0=0 and sv=0.
# 1. Simulate the model and confidence outcomes and Aggregate Rating Distribution####
# 2. Compute the distribution of confidence judgements with my own methods  ####
# 3. compute the rating distribution and the density of RT on observed range and the conf distribution with my package   ####
# 4. Plot the distributions of simulations and the package together ####
########################



# 0. Load packages and set parameter set:
cat("\014")
rm(list=ls())
library(tidyverse)
library(dynWEV)
load("E:/AccumModelsMac/newRMt_modelfits_threecoefficients.RData")
#load("../AccumulatorModels/saved_data/fits_RacingModels.RData")
nConds <- 1
nRatings <-5
trimmean <- function(x) {
  x <- x[x<100]
  mean(x)
}
names(fits_RMmodels)
paramDf <- fits_RMmodels %>% group_by(model) %>%
  summarise(across(.cols = 2:22, .fns = trimmean))

# 1. Simulate the model and confidence outcomes and Aggregate Rating Distribution####
n <- 10^4
## Simulations
paramDf$v1 <- paramDf$v4
paramDf <- paramDf%>% select(-c("v2", "v3", "v4", "v5"))

simus <- paramDf %>% group_by(model) %>%
  summarise(rRM(cur_data(), n = n, model = .data$model, time_scaled = FALSE, gamma = FALSE, agg_simus = FALSE))

## Aggregate Rating Distribution
Agg_RatingDist_Simus <- simus %>% group_by(rating, correct,model, condition) %>%
  summarise(p = n()/(2*n)) %>%
  full_join(y=expand.grid(rating=1:nRatings, correct=c(0,1), condition = 1,
                          model=c("IRMt", "PCRMt"))) %>%
  mutate(p = ifelse(is.na(p), 0, p))
sum(Agg_RatingDist_Simus$p)
Agg_RatingDist_Simus %>% group_by(condition, model) %>% summarise(p=sum(p))
Agg_MRating_Simus <- Agg_RatingDist_Simus %>% group_by(model, condition, correct) %>%
  summarise(MRating = sum(p*rating)/sum(p))



# 3. Predict the rating distribution with my package   ####
## Rating Distribution
preds_pckg <- paramDf %>% group_by(model) %>%
  summarise(predictRM_Conf(cur_data(),model=cur_data_all()$model[1], time_scaled=FALSE,.progress = TRUE))
preds_pckg %>% group_by(condition, stimulus, model) %>% summarise(p=sum(p))


##   Combine and Aggregate Confidence Rating Distribution   ##
Preds_RatingDist_corr_cond <- preds_pckg %>%
  group_by(model, rating, correct, condition) %>%
  summarise(p = mean(p)) %>%
  mutate(model = factor(model, levels = c("IRMt","PCRMt"),
                        labels = c( "IRMt", "PCRMt")),
         condition = factor(condition,levels = 1:nConds))
# # # Sanity checks:
# Preds_RatingDist_corr_cond %>% filter(model %in% c("IRMt", "PCRMt")) %>%
#   group_by(model, condition) %>% summarise(p = sum(p))
# Preds_RatingDist_corr_cond %>% group_by(model, condition) %>%
#   summarise(p=sum(p))
##    Compute Mean Rating Accross Conditions
# This is good to visualize a folded-X- and double-increase-pattern
Preds_MRating_corr_cond <- Preds_RatingDist_corr_cond %>% group_by(model, condition, correct) %>%
  summarise(MRating = sum(p*rating)/sum(p))


ggplot()+
  geom_bar(data=Agg_RatingDist_Simus, aes(x=rating, y=p), stat="identity")






