rm(list=ls())
Rcpp::sourceCpp("src/RTSDSDT.cpp")
# pkgload::load_all()
# pkgbuild::compile_dll()


time_scaled=TRUE
paramDf <- list(mu1=1.5, mu2=0.5,
                a=-2.5, b=-0.3, s=1,
                th1 = 0.1, th2 = 0.4,
                st0=1, w=0.2)

#sdrift=0.0
#n <- 6000
#delta <- 0.01


rts <- 1.5
d_IRM(rts, as.numeric(paramDf), win=1, time_scaled)
rts <- c(0.5, 0.7, 1, 2, 3)
d_IRM(rts, as.numeric(paramDf), win=1, time_scaled)
rts <- seq(0,3, length.out = 400)
plot(rts, d_IRM(rts, as.numeric(paramDf), win=1, time_scaled), type="l")
points(rts, d_PCRM(rts, as.numeric(paramDf), win=1, time_scaled), type="l", lty="dashed")


plot(rts, d_PCRM(rts, as.numeric(paramDf), win=1, time_scaled), type="l")
paramDf2 <- paramDf
paramDf2$st0=0
points(rts, d_PCRM(rts, as.numeric(paramDf2), win=1, time_scaled), type="l", lty="dashed")



paramDf <- list(mu1=.4, mu2=-.4,
                a=-1.6, b=-1.7, s=1.2,
                th1 = 0, th2 = Inf,
                st0=1, w=0.2)

rts <- seq(-1,3, length.out = 400)
plot(rts, d_IRM(rts, as.numeric(paramDf), win=1, time_scaled), type="l")
points(rts, d_IRM(rts, as.numeric(paramDf), win=2, time_scaled), type="l", col="red")
points(rts, d_PCRM(rts, as.numeric(paramDf), win=1, time_scaled), type="l", lty="dashed")
points(rts, d_PCRM(rts, as.numeric(paramDf), win=2, time_scaled), type="l", lty="dashed",col="red")
# , step_width = 1e-8/(3*paramDf$st0)
int_IRM1 <- integrate(function(t) d_IRM(t, as.numeric(paramDf), 1, time_scaled), 0, Inf)
int_IRM2 <- integrate(function(t) d_IRM(t, as.numeric(paramDf), 2, time_scaled), 0, Inf)
int_PCRM1 <- integrate(function(t) d_PCRM(t, as.numeric(paramDf), 1, time_scaled), 0, Inf)
int_PCRM2 <- integrate(function(t) d_PCRM(t, as.numeric(paramDf), 2, time_scaled), 0, Inf)
print(int_IRM1)
print(int_IRM2)
int_IRM1$value+int_IRM2$value
print(int_PCRM1)
print(int_PCRM2)
int_PCRM1$value+int_PCRM2$value



plot(rts, d_PCRM(rts, as.numeric(paramDf), win=1, time_scaled), type="l")
paramDf2 <- paramDf
paramDf2$st0=0
points(rts, d_PCRM(rts, as.numeric(paramDf2), win=1, time_scaled), type="l", lty="dashed")





d_IRM(0.02564103, as.numeric(paramDf), win=1)
integrate(function(t) d_IRM(t, as.numeric(paramDf), 1), 0, Inf)
integrate(function(t) d_IRM(t, as.numeric(paramDf), 2), 0, Inf)

## Compare to previously implemented functions
source("test/dens_losingAcc_MorenoBote.R")
plot(rts[-1], dboundaccMorenoBote(rts[-1], 1, -0.5, c(paramDf, rho=0), formula="long"), type="l")
points(rts[-1], dd_IRM(rts[-1], -0.5, as.numeric(paramDf),win=1), type="l", col="red")
points(rts[-1], dd_IRM(rts[-1], -0.5, as.numeric(paramDf),win=1, method=2), type="l", col="blue")
points(rts[-1], dboundaccMorenoBote(rts[-1], 1, -0.5, c(paramDf, rho=0), formula="short"), type="l", col="green", lty="dashed")
plot(rts[-1], dboundaccMorenoBote(rts[-1], 2, -0.5, c(paramDf, rho=0), formula="long"), type="l")
points(rts[-1], dd_IRM(rts[-1], -0.5, as.numeric(paramDf),win=2), type="l", col="red")
points(rts[-1], dd_IRM(rts[-1], -0.5, as.numeric(paramDf),win=2, method=2), type="l", col="blue")

# Now, for a==b
paramDf$b = paramDf$a
plot(rts[-1], dboundaccMorenoBote(rts[-1], 1, -0.5, c(paramDf, rho=0), formula="long"), type="l")
points(rts[-1], dd_IRM(rts[-1], -0.5, as.numeric(paramDf),win=1), type="l", col="red")
points(rts[-1], dd_IRM(rts[-1], -0.5, as.numeric(paramDf),win=1, method=2), type="l", col="blue")
points(rts[-1], dboundaccMorenoBote(rts[-1], 1, -0.5, c(paramDf, rho=0), formula="short"), type="l", col="green", lty="dashed")
plot(rts[-1], dboundaccMorenoBote(rts[-1], 2, -0.5, c(paramDf, rho=0), formula="long"), type="l")
points(rts[-1], dd_IRM(rts[-1], -0.5, as.numeric(paramDf),win=2), type="l", col="red")
points(rts[-1], dd_IRM(rts[-1], -0.5, as.numeric(paramDf),win=2, method=2), type="l", col="blue")
points(rts[-1], dboundaccMorenoBote(rts[-1], 2, -0.5, c(paramDf, rho=0), formula="short"), type="l", col="green", lty="dashed")


### Do we get the same values for discrete confidence when integrating in R?
rts <- seq(0,3, length.out = 400)
plot(rts, d_IRM(rts, as.numeric(paramDf), win=1), type="l")
d_IRM_R <- function(rts, paramDf, win, formula) {
  out <- rep(0, length(rts))
  paramDf
  for (i in 1:length(rts)) {
    t <- rts[i]
    integrand <- Vectorize(function(xj) dboundaccMorenoBote(t, win, xj, c(paramDf, rho=0), formula = formula))
    out[i] = integrate(integrand, lower=paramDf$vth1, upper = paramDf$vth2)$value

  }
  return(out)
}
points(rts[c(10, 50, 70, 100, 200, 250, 300)], d_IRM_R(rts[c(10, 50, 70, 100, 200, 250, 300)], paramDf, 1, "short"), col="red", pch="X")
points(rts[c(10, 50, 70, 100, 200, 250, 300)], d_IRM_R(rts[c(10, 50, 70, 100, 200, 250, 300)], paramDf, 1, "long"), col="green", pch="X")




### Now for rho!=0
rts <- seq(0,3, length.out = 400)
paramDf$b = -0.3  ### works both
#paramDf$b = paramDf$a
plot(rts[-1], dboundaccMorenoBote(rts[-1], 1, -0.5, c(paramDf, rho=-0.5), formula="long"), type="l")
points(rts[-1], dd_PCRM(rts[-1], -0.5, as.numeric(paramDf),win=1), type="l", col="red")
points(rts[-1], dboundaccMorenoBote(rts[-1], 1, -0.5, c(paramDf, rho=-0.5), formula="short"), type="l", col="green", lty="dashed")
plot(rts[-1], dboundaccMorenoBote(rts[-1], 2, -0.5, c(paramDf, rho=-0.5), formula="long"), type="l")
points(rts[-1], dd_PCRM(rts[-1], -0.5, as.numeric(paramDf),win=2), type="l", col="red")
points(rts[-1], dboundaccMorenoBote(rts[-1], 2, -0.5, c(paramDf, rho=-0.5), formula="short"), type="l", col="green", lty="dashed")


rts <- 0.67
paramDf$b = -0.3  ### works both
#paramDf$b = paramDf$a
xj <- seq(paramDf$b-2, paramDf$b, length.out = 300)
plot(xj, dboundaccMorenoBote(rts, 1, xj, c(paramDf, rho=-0.5), formula="long"), type="l")
points(xj, dd_PCRM(rts, xj, as.numeric(paramDf),win=1), type="l", col="red")
points(xj, dboundaccMorenoBote(rts, 1, xj, c(paramDf, rho=-0.5), formula="short"), type="l", col="green", lty="dashed")
plot(xj, dboundaccMorenoBote(rts, 2, xj, c(paramDf, rho=-0.5), formula="long"), type="l")
points(xj, dd_PCRM(rts, xj, as.numeric(paramDf),win=2), type="l", col="red")
points(xj, dboundaccMorenoBote(rts, 2, xj, c(paramDf, rho=-0.5), formula="short"), type="l", col="green", lty="dashed")





### Do we get the same values for discrete confidence when integrating in R?
rts <- seq(0,4, length.out = 400)
d_PCRM_R <- function(rts, paramDf, win) {
  out <- rep(0, length(rts))
  paramDf
  for (i in 1:length(rts)) {
    t <- rts[i]
    integrand <- Vectorize(function(xj) dboundaccMorenoBote(t, win, xj, c(paramDf, rho=-0.5), formula = "long"))
    out[i] = integrate(integrand, lower=paramDf$vth1, upper = paramDf$vth2)$value

  }
  return(out)
}
d_PCRM_CppR <- function(rts, paramDf, win) {
  out <- rep(0, length(rts))
  paramDf
  for (i in 1:length(rts)) {
    t <- rts[i]
    integrand <- Vectorize(function(xj) dd_PCRM(t, xj, as.numeric(paramDf),win=win))
    out[i] = integrate(integrand, lower=paramDf$vth1, upper = paramDf$vth2)$value

  }
  return(out)
}
plot(rts[-1], d_PCRM_CppR(rts[-1], paramDf, 1), col="red", type="l")
points(rts[c(10, 50, 70, 100, 200, 250, 300)], d_PCRM_R(rts[c(10, 50, 70, 100, 200, 250, 300)], paramDf, 1), col="green", pch="X")
points(rts, d_PCRM(rts, as.numeric(paramDf), win=1), type="l", lty="dashed")






paramDf <- list(mu1=.4, mu2=-.4,
                a=-1.6, b=-1.7, s=1.2,
                th1 = 0.5, th2 = 1.5,
                st0=0.02, w=2)
rts <- seq(0,3, length.out = 400)
plot(rts, d_PCRM(rts, as.numeric(paramDf), win=1), type="l")

paramDf
integrate(function(t) d_PCRM(t, as.numeric(paramDf), 1), 0, Inf)
integrate(function(t) d_PCRM(t, as.numeric(paramDf), 2), 0, Inf)
paramDf$th1 <- -200
paramDf$th2 <- 0
integrate(function(t) d_PCRM(t, as.numeric(paramDf), 1), 0, Inf)
integrate(function(t) d_PCRM(t, as.numeric(paramDf), 2), 0, Inf)


#erf <- function(x) 2*pnorm(x)-1
#pow <- function(x,y) x^y





paramDf <- list(mu1=0.7, mu2=-0.7, a=-2.5, b=-2, s=1)
simus <- r_RM(30000, as.numeric(paramDf), indep = TRUE, delta=0.005, maxT=7)
library(ggplot2)
simus <- as.data.frame(simus)
names(simus) <- c("t", "win", "xl")
ggplot(simus) +
  geom_density2d(aes(x=t, y=xl))+
  facet_grid(.~win)+
  ylim(c(-3,0))+
  xlim(c(0,2))
ggplot(simus) +
  geom_density_2d_filled(aes(x=t, y=xl))+
  facet_grid(.~win)+
  ylim(c(-3,0))+
  xlim(c(0,2))

simus <- r_RM(30000, as.numeric(paramDf), indep = FALSE, delta=0.005, maxT=7)
library(ggplot2)
simus <- as.data.frame(simus)
names(simus) <- c("t", "win", "xl")
ggplot(simus) +
  geom_density2d(aes(x=t, y=xl))+
  facet_grid(.~win)+
  ylim(c(-3,0))+
  xlim(c(0,2))
ggplot(simus) +
  geom_density_2d_filled(aes(x=t, y=xl))+
  facet_grid(.~win)+
  ylim(c(-3,0))+
  xlim(c(0,2))
summary(simus$xl)



### Test seeding
seed = 4242
paramDf <- list(mu1=0.7, mu2=-0.7, a=-2.5, b=-2, s=1)
# without seed
r_RM(10, as.numeric(paramDf), indep = FALSE, delta=0.005, maxT=7)
r_RM(10, as.numeric(paramDf), indep = FALSE, delta=0.005, maxT=7)
# with seed
set.seed(seed)
r_RM(10, as.numeric(paramDf), indep = FALSE, delta=0.005, maxT=7)
set.seed(seed)
r_RM(10, as.numeric(paramDf), indep = FALSE, delta=0.005, maxT=7)


source("R/rRM.R")
set.seed(seed)
rRM_CPP(10, paramDf, model="PCRM", delta=0.005, maxT = 7)
set.seed(seed)
rRM_CPP(10, paramDf, model="PCRM", delta=0.005, maxT = 7)



rRM_CPP(10, paramDf, model="PCRM", delta=0.01, maxT = 7)



## Test RNG
source("../AccumulatorModels/DecisionModels_withoutConfidence/competing_accumulators/f_sim_BoundAcc_MorenoBote.R")
library(tidyverse)
paramDf2 <- paramDf
paramDf2$a <- -paramDf2$a
paramDf2$b <- -paramDf2$b
simus_R <- rBoundedAcc(10000, c(paramDf2, rho=0))
simus_R <- simus_R %>% filter(resp!=0) %>%
  mutate(xj=  xj-c(paramDf2$b, paramDf2$a)[resp])
simus_Cpp <- as.data.frame(r_RM(10000, as.numeric(paramDf), indep=TRUE, delta=0.01, maxT=7))
names(simus_Cpp) <- c("rts", "resp", "xj")

simus <- rbind(cbind(simus_R, class="R"), cbind(simus_Cpp, class="Cpp"))
ggplot(filter(simus, simus$resp!=0)) +
  geom_density2d(aes(x=rts, y=xj, group=class, color=class))+
  facet_grid(.~resp)
