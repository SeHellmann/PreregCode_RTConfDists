paramDf <- structure(list(mu1 = 1.5, mu2 = 0.5, a = 2.5, b = 2.5, s = 1,
                          t0 = 0.1, st0 = 0.5, th1 = 0, th2 = 20000, wx = 4.1, wint = 4.123,
                          wrt = 5), row.names = c(NA, -1L), class = "data.frame")
resp <- 1
integrand <- function(t) {
  dIRM(t,resp,  paramDf)
}

Ints <- integrate(integrand, lower = paramDf$t0, upper = 15, subdivisions = 800)$value #+


rts <- c(1.2917210, 0.4016822, 2.1817598, 0.5011523, 2.0822897, 0.6708186, 1.9126234,
         0.8956473, 1.6877947, 1.1556669, 1.4277751, 0.3818046, 2.2016374, 0.4416638,
         2.1417782, 0.5781432, 2.0052988, 0.7774256, 1.8060165, 1.0226797, 1.5607623)
dIRM(rts,resp,  paramDf)
rts[12]
dIRM(rts[12]-1e-5,2,  paramDf)
dIRM(rts[12]+1e-5,2,  paramDf)

paramDf$t0
min(rts)
# rts <- seq(0, rts[12], length.out=700)
# dIRM(rts,resp,  paramDf)




inv_sqrt_2pi = 0.3989422804014327;

length = length(rts);
out <- rep(0,length);
win <- resp
params <- paramDf
muw = params[['mu1']];
mul = params[['mu2']];
a = params[['a']];
b = params[['b']];
sigma = params[['s']];
th1 = params[['th1']];
th2 = params[['th2']];
st0 = params[['st0']];
wx = params[['wx']];
wrt = params[['wrt']];
wint = params[['wint']];
rts <- rts- params[['t0']]


EPSILON <- 1e-6
if (st0 < EPSILON) {
  st0 = 0;
}
step_width =  0.089045 * exp(-1.037580*4)
if (st0 == 0) {
  nsteps=1;
  dt=0;
} else {
  nsteps = max(4, as.integer(st0/step_width));
  dt = st0 / nsteps;
}



fac = inv_sqrt_2pi/(4*sigma);
C = c(1, -1, -1, 1);
expC1 = c(a, 0, a);
expC2 = c(0, b, b);

expC = -2/(sigma*sigma) * (muw*expC1 + mul*expC2);

expC <- c(0, expC)

Xis = matrix(c(a, -a, a, -a,
  b, b, -b, -b), nrow = 4, ncol=2);


library(gsl)
densIRM_differbounds <- function(t, th2, th1, sigma,  muw, mul, wx, wrt, wint,
                                    C,  expC, Xis){
  sig2t = 2*sigma*sigma*t;
  temp = 0;
  tth2 <- (-th1*sqrt(t)+wrt)/(sqrt(t)*wx + wint);
  tth1 <- (-th2*sqrt(t)+wrt)/(sqrt(t)*wx + wint);
  for (j in 1:4) {
    x1tilde = -Xis[j,1]-muw*t;
    temp = temp + C[j]* exp(expC[j] - (x1tilde)*(x1tilde)/(sig2t)) * x1tilde *
      (erf((tth2-Xis[j,2]-mul*t)/sqrt(sig2t)) - erf((tth1-Xis[j,2]-mul*t)/sqrt(sig2t)));
  }
  res = temp/(t^1.5);
  return(res);
}

integrate_densIRM_differbounds_over_t <- function(tmin,tmax, dt, th2, th1, sigma, muw,mul,wx, wrt, wint,
                                                  C, expC, Xis) {
  result = 0;
  Ts <- seq(tmin+0.5*dt, tmax,  dt)
  Ts <- Ts[2:length(Ts)]
  for(x in Ts)
  {
    if (x > 0) {
      result =  result + dt * densIRM_differbounds ( x,  th2,  th1,  sigma,  muw,  mul,
                                                     wx, wrt, wint, C, expC, Xis);
    }
  }
  return(result);
}

#endif // DENSITY_IRM_H





for (i in 1:length) {
  if (rts[i] < 0 ) {
    out[i] = 0;
  } else {
    out[i] = fac / st0 *
      integrate_densIRM_differbounds_over_t(tmin= rts[i]-st0, tmax = rts[i], dt = dt,
                              th2 = th2,  th1 = th1,  sigma = sigma,  muw,  mul,
                              wx, wrt, wint, C, expC, Xis);
  }
}








