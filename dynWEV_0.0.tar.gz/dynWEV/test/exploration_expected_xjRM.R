row
a <- row$a
b <- row

expectationPCRM <- Vectorize(function(mu) {
  row$mu1 <- mu
  row$mu2 <- -mu
  pt <- Vectorize(function(rt) integrate(function(xj) xj*ddPCRM(rt, 1, xj,row), lower=-Inf, upper=row$b,
                               subdivisions = 200, stop.on.error = FALSE)$value)
  return(integrate(pt, lower=0, upper=Inf, subdivisions = 300)$value)
})
mu <- seq(0.01, 5, length.out = 15)
exp_xj <- expectationPCRM(mu)
plot(mu, exp_xj)


t_expectationPCRM <- Vectorize(function(mu) {
  row$mu1 <- mu
  row$mu2 <- -mu
  pt <- Vectorize(function(rt) integrate(function(xj) rt*ddPCRM(rt, 1, xj,row), lower=-Inf, upper=row$b,
                                         subdivisions = 200, stop.on.error = FALSE)$value)
  return(integrate(pt, lower=0, upper=Inf, subdivisions = 300)$value)
})
mu <- seq(0.01, 5, length.out = 15)
exp_t <- t_expectationPCRM(mu)
plot(mu, exp_t)


t2_expectationPCRM <- Vectorize(function(mu) {
  row$mu1 <- mu
  row$mu2 <- -mu
  row$th1 <- 0
  row$th2 <- 1e32

  pt <- Vectorize(function(rt) rt*dPCRM(rt, 1, row, time_scaled = FALSE))
  return(integrate(pt, lower=0, upper=Inf, subdivisions = 300)$value)
})
mu <- seq(0.01, 20, length.out = 40)
exp_t2 <- t2_expectationPCRM(mu)
plot(mu, exp_t2)
#points(mu, exp_t, col="red")
