rm(list=ls())
library(dynWEV)
library(tidyverse)

paramDf <- data.frame(mu1=1.5, mu2=0.5, a=2.5, b=1.7, s=1, t0=0.2, st0=0.000002)
paramDf$th1 <- -0.4+1.7
paramDf$th2 <- -0.1+1.7

rts <- 1.5
dIRM(rts, 1,paramDf)

rts <- c(0.5, 0.7, 1, 2, 3)
dIRM(rts, 1, paramDf)
rts <- seq(0,3, length.out = 400)
plot(rts, dIRM(rts, 1, paramDf), type="l")
points(rts, dIRM(rts, 2, paramDf), type="l", lty=2, col="red")
integrate(function(t) dIRM(t, 1, paramDf), 0, Inf)
integrate(function(t) dIRM(t, 2, paramDf), 0, Inf)

rts <- seq(0,3, length.out = 400)
plot(rts, dPCRM(rts, 1, paramDf), type="l")
points(rts, dPCRM(rts, 2, paramDf), type="l", lty=2, col="red")

# Now, for a==b
paramDf$b = paramDf$a
plot(rts, dIRM(rts, 1, paramDf), type="l")
points(rts, dIRM(rts, 2, paramDf), type="l", lty=1, col="red")
paramDf$b = paramDf$b + 0.01
points(rts, dIRM(rts, 1, paramDf), type="l", lty=2)
points(rts, dIRM(rts, 2, paramDf), type="l", lty=2, col="red")



### Check scaling with sigma
rts <- seq(0,3, length.out = 400)
paramDf <- data.frame(mu1=1.5, mu2=0.5, a=2.5, b=1.7, s=1, t0=0, st0=0)
paramDf$th1 <- -0.4+1.7
paramDf$th2 <- -0.1+1.7
plot(rts, dIRM(rts, 1, paramDf), type="l")
points(rts, dPCRM(rts, 1, paramDf), type="l", col="red")
paramDf[,-c(6,7)] <- paramDf[,-c(6,7)]*2
points(rts, dIRM(rts, 1, paramDf), type="l", lty=2, col="gray")
points(rts, dPCRM(rts, 1, paramDf), type="l", lty=2, col="darkred")



# rts <- rts <- seq(0,10, length.out = 3000000)
# t00 <- Sys.time()
# paramDf$b = 2.488
# dens_uneq1 <- dIRM(rts, 1, paramDf)
# dens_uneq2 <- dIRM(rts, 2, paramDf)
# time_uneq <- difftime(Sys.time(), t00)
# t00 <- Sys.time()
# paramDf$b = paramDf$a
# dens_eq1 <- dIRM(rts, 1, paramDf)
# dens_eq2 <- dIRM(rts, 2, paramDf)
# time_eq <- difftime(Sys.time(), t00)
# print(paste("Time for equal thresholds: ", time_eq, sep=""))
# print(paste("Time for unequal thresholds: ", time_uneq, sep=""))
#### Time test, output:
# # > print(paste("Time for equal thresholds: ", time_eq, sep=""))
# # [1] "Time for equal thresholds: 5.80100011825562"
# # > print(paste("Time for unequal thresholds: ", time_uneq, sep=""))
# # [1] "Time for unequal thresholds: 15.0564460754395"





### Now for rho!=0
rts <- seq(0,3, length.out = 400)
paramDf$b = 0.9  ### works both
#paramDf$b = paramDf$a

paramDf2 <- paramDf
paramDf2$a <- -paramDf2$a
paramDf2$b <- -paramDf2$b
xj <- 0.5
xj2 <- 0.5-paramDf$b
xj1 <- 0.5-paramDf$a

plot(rts[-1], ddPCRM(rts[-1], 1, xj, paramDf), type="l", col="red")
points(rts[-1], ddPCRM(rts[-1], 2, xj, paramDf), type="l", col="red")
paramDf <- paramDf/paramDf$s
xj <- xj/paramDf$s
points(rts[-1], ddPCRM(rts[-1], 1, xj, paramDf), type="l")
points(rts[-1], ddPCRM(rts[-1], 2, xj, paramDf), type="l")



paramDf$st0=0
paramDf$t0 = 0
paramDf
rts <- seq(0,3, length.out = 400)
plot(rts, dPCRM(rts,1, paramDf), type="l")



paramDf
integrate(function(t) dPCRM(t,1, paramDf), 0, Inf)
integrate(function(t) dPCRM(t,2,  paramDf), 0, Inf)
paramDf$th1 <- 0
paramDf$th2 <- 20000
integrate(function(t) dPCRM(t,1,  paramDf, time_scaled = FALSE), 0, Inf)
integrate(function(t) dPCRM(t,2,  paramDf, time_scaled = FALSE), 0, Inf)
integrate(function(t) dIRM(t,1,  paramDf, time_scaled = FALSE), 0, Inf)
integrate(function(t) dIRM(t,2,  paramDf, time_scaled = FALSE), 0, Inf)

paramDf$wx <- 1
paramDf$wint <- 2.5
paramDf$wrt <- 0.5
integrate(function(t) dPCRM(t,1,  paramDf, time_scaled = TRUE), 0, Inf)
integrate(function(t) dPCRM(t,2,  paramDf, time_scaled = TRUE), 0, Inf)
integrate(function(t) dIRM(t,1,  paramDf, time_scaled = TRUE), 0, Inf)
integrate(function(t) dIRM(t,2,  paramDf, time_scaled = TRUE), 0, Inf)

paramDf$wx <- 1
paramDf$wint <- 0
paramDf$wrt <- 0
integrate(function(t) dPCRM(t,1,  paramDf, time_scaled = TRUE), 0, Inf)
integrate(function(t) dPCRM(t,2,  paramDf, time_scaled = TRUE), 0, Inf)
integrate(function(t) dIRM(t,1,  paramDf, time_scaled = TRUE), 0, Inf)
integrate(function(t) dIRM(t,2,  paramDf, time_scaled = TRUE), 0, Inf)

integrate(function(t) dPCRM(t,1,  paramDf, time_scaled = FALSE), 0, Inf)
integrate(function(t) dPCRM(t,2,  paramDf, time_scaled = FALSE), 0, Inf)
integrate(function(t) dIRM(t,1,  paramDf, time_scaled = FALSE), 0, Inf)
integrate(function(t) dIRM(t,2,  paramDf, time_scaled = FALSE), 0, Inf)







paramDf$t0 <- 0
paramDf$st0 <- 0
paramDf$wx <- 10
paramDf$wint <- 20.123
paramDf$wrt <- 0.0000005
integrate(function(t) dPCRM(t,1,  paramDf, time_scaled = TRUE), 0, Inf)$value +
  integrate(function(t) dPCRM(t,2,  paramDf, time_scaled = TRUE), 0, Inf)$value
integrate(function(t) dIRM(t,1,  paramDf, time_scaled = TRUE), 0, Inf)$value +
  integrate(function(t) dIRM(t,2,  paramDf, time_scaled = TRUE), 0, Inf)$value

paramDf$t0 <- 0.5
paramDf$st0 <- 0.2
integrate(function(t) dPCRM(t,1,  paramDf, time_scaled = TRUE), 0.5, Inf)$value +
  integrate(function(t) dPCRM(t,2,  paramDf, time_scaled = TRUE), 0.5, Inf)$value
integrate(function(t) dIRM(t,1,  paramDf, time_scaled = TRUE), 0.5, Inf)$value +
  integrate(function(t) dIRM(t,2,  paramDf, time_scaled = TRUE), 0.5, Inf)$value



paramDf$b <- paramDf$a
rts <- seq(0,3, length.out = 400)
plot(rts, dPCRM(rts,1, paramDf), type="l")
paramDf$w = 1.5
points(rts, dPCRM(rts,1, paramDf, time_scaled = TRUE), type="l", col="red")

paramDf
integrate(function(t) dPCRM(t,1, paramDf), 0, Inf)
integrate(function(t) dPCRM(t,2,  paramDf), 0, Inf)
paramDf$th1 <- 0
paramDf$th2 <- 200
integrate(function(t) dPCRM(t,1,  paramDf), 0, Inf)
integrate(function(t) dPCRM(t,2,  paramDf), 0, Inf)
integrate(function(t) dIRM(t,1,  paramDf), 0, Inf)
integrate(function(t) dIRM(t,2,  paramDf), 0, Inf)
integrate(function(t) dPCRM(t,1,  paramDf, time_scaled = TRUE ), 0, Inf)
integrate(function(t) dPCRM(t,2,  paramDf, time_scaled = TRUE), 0, Inf)
integrate(function(t) dIRM(t,1,  paramDf, time_scaled = TRUE), 0, Inf)
integrate(function(t) dIRM(t,2,  paramDf, time_scaled = TRUE), 0, Inf)



paramDf <- list(a = 0.754173365669477,b = 0.885015280000596, s = 0.935375502273285, t0 = 0.377835741372225,
                          st0 = 1.00034222556902e-06, w = NA_real_, mu1 = 0.883796822634184,
                mu2 = - 0.883796822634184, th1 = 0, th2=1e+32)
paramDf$w = 1.5

Sts <- seq(0.9, 8.8, by=0.01) * 1e-6
Ints <- NULL
# Ints <- matrix(NA, nrow = 4, ncol=length(Sts))
#for (resp in 1:2) {
resp = 1

  for (i in 1:length(Sts)) {
    st0 <- Sts[i]
    paramDf$st0 <- st0
    # Ints[i] <- integrate(function(t) dPCRM(t,1,  paramDf), 0, Inf)$value +
    #   integrate(function(t) dPCRM(t,2,  paramDf), 0, Inf) $ value

    Ints[i] <- integrate(function(t) dIRM(t,resp,  paramDf), 0, Inf)$value +
       integrate(function(t) dIRM(t,2,  paramDf), 0, Inf) $ value

    # Ints[1, i] <- integrate(function(t) dPCRM(t,1,  paramDf), 0, Inf)$value +
    #   integrate(function(t) dPCRM(t,2,  paramDf), 0, Inf) $ value
    # Ints[2, i] <- integrate(function(t) dIRM(t,1,  paramDf), 0, Inf)$value +
    #   integrate(function(t) dIRM(t,2,  paramDf), 0, Inf)$value
    # Ints[3, i] <- integrate(function(t) dPCRM(t,1,  paramDf, time_scaled = TRUE ), 0, Inf)$value +
    #   integrate(function(t) dPCRM(t,2,  paramDf, time_scaled = TRUE), 0, Inf)$value
    # Ints[4, i] <- integrate(function(t) dIRM(t,1,  paramDf, time_scaled = TRUE), 0, Inf)$value +
    #   integrate(function(t) dIRM(t,2,  paramDf, time_scaled = TRUE), 0, Inf)$value
  }
  if (resp==1) {
    plot(Sts, Ints, xlab = "st0", ylab="Total predicted probability", ylim=c(0,2))
  } else {
    points(Sts, Ints, col="red")
  }
#}

t <- 0.63
paramDf$st0 <- seq(0.9, 8.8, by=0.01) * 1e-6
P1 <- dPCRM(rep(t, length(paramDf$st0)), 1, paramDf, time_scaled = FALSE, step_width = 0.13)
P2 <- dPCRM(rep(t, length(paramDf$st0)), 2, paramDf, time_scaled = FALSE, step_width = 0.13)
plot(paramDf$st0, P1, ylim = c(0,2.65))
points(paramDf$st0, P2, col="red")

Sts <- seq(0.1, 8.8, by=0.1) * 1e-2
Ints <- NULL
# Ints <- matrix(NA, nrow = 4, ncol=length(Sts))
for (resp in 1:2) {
  for (i in 1:length(Sts)) {
    st0 <- Sts[i]
    paramDf$st0 <- st0
    # Ints[i] <- integrate(function(t) dPCRM(t,1,  paramDf), 0, Inf)$value +
    #   integrate(function(t) dPCRM(t,2,  paramDf), 0, Inf) $ value

    Ints[i] <- integrate(function(t) dIRM(t,resp,  paramDf), 0, 15)$value +
      integrate(function(t) dIRM(t,2,  paramDf), 0, 15) $ value

    # Ints[1, i] <- integrate(function(t) dPCRM(t,1,  paramDf), 0, Inf)$value +
    #   integrate(function(t) dPCRM(t,2,  paramDf), 0, Inf) $ value
    # Ints[2, i] <- integrate(function(t) dIRM(t,1,  paramDf), 0, Inf)$value +
    #   integrate(function(t) dIRM(t,2,  paramDf), 0, Inf)$value
    # Ints[3, i] <- integrate(function(t) dPCRM(t,1,  paramDf, time_scaled = TRUE ), 0, Inf)$value +
    #   integrate(function(t) dPCRM(t,2,  paramDf, time_scaled = TRUE), 0, Inf)$value
    # Ints[4, i] <- integrate(function(t) dIRM(t,1,  paramDf, time_scaled = TRUE), 0, Inf)$value +
    #   integrate(function(t) dIRM(t,2,  paramDf, time_scaled = TRUE), 0, Inf)$value
  }
  if (resp==1) {
    plot(Sts, Ints, xlab = "st0", ylab="Total predicted probability", ylim=c(0,2))
  } else {
    points(Sts, Ints, col="red")
  }
}



rts <- seq(paramDf$t0-0.01,3, length.out = 200)
paramDf$st0 <- 0
plot(rts, dPCRM(rts, 1, paramDf), type="l", ylim = c(0,2))
Sts <- seq(1.001, 4, length.out=5) * 1e-6
for (i in 1:length(Sts)) {
  st0 <- Sts[i]
  paramDf$st0 <- st0
  points(rts, dIRM(rts, 1, paramDf), type="l", lty=2, col=i, cex=2)
  #Sys.sleep(15)
}
legend("topright", lty=1, col=1:length(Sts), legend=Sts)



Sts <- seq(0.9, 8.8, by=0.01) * 1e-6
Sts <- Sts[c(1, 7, 10, 20, 80)]
rts <- seq(paramDf$t0-0.01,3, length.out = 400)
paramDf$st0 <- 0
plot(rts, dPCRM(rts, 1, paramDf), type="l", ylim = c(0,2))
for (i in 1:length(Sts)) {
  st0 <- Sts[i]
  paramDf$st0 <- st0
  points(rts, dPCRM(rts, 1, paramDf), type="l", lty=2, col=i)

}
legend("topright", lty=1, col=1:length(Sts), legend=paste(Sts, round(Ints[c(1, 7, 10, 20, 80)], 4)))


st0
dens <- dPCRM(rts, 1, paramDf)
dens
rts
abline(v=0.63)
# 20, 21
rts[c(20,21)]
dens[c(20, 21)]

rts2 <- seq(0.627833, 0.62784, length.out=500)
plot(rts2,dPCRM(rts2, 1, paramDf) )

library(cubature)
int_1 <- adaptIntegrate(function(XT) ddIRM(XT[2], response=1, xj=XT[1], params = paramDf),
               lowerLimit = c(-Inf, 0),
               upperLimit = c(paramDf$b, Inf))
int_2 <- adaptIntegrate(function(XT) ddIRM(XT[2], response=2, xj=XT[1], params = paramDf),
               lowerLimit = c(-Inf, 0),
               upperLimit = c(paramDf$a, Inf))
int_1
int_2
int_1$integral + int_2$integral


int_1 <- adaptIntegrate(function(XT) ddPCRM(XT[2], response=1, xj=XT[1], params = paramDf),
                        lowerLimit = c(-Inf, 0),
                        upperLimit = c(paramDf$b, Inf))
int_2 <- adaptIntegrate(function(XT) ddPCRM(XT[2], response=2, xj=XT[1], params = paramDf),
                        lowerLimit = c(-Inf, 0),
                        upperLimit = c(paramDf$a, Inf))
int_1
int_2
int_1$integral + int_2$integral


#erf <- function(x) 2*pnorm(x)-1
#pow <- function(x,y) x^y






### Test random generator
#library(Hmisc)
paramDf <- data.frame(v1 = 0.1, v2=0.5, v3=1, a=0.8, b=0.6, s=1, theta1 = 0.2, theta2= 1, theta3=2)
stimulus = c(1,2)
delta = 0.01
maxrt = 15
n = 20000
time_scale=TRUE
model = "IRM"
simus_pckg <- rRM(paramDf)





paramDf <- data.frame(v1=0.5,a=0.8, b=0.6, s=1, theta1 = 0.2, theta2= 1, theta3=2)
stimulus = c(1)
delta = 0.01
maxrt = 15
n = 20000
time_scaled=TRUE
model = "PCRM"
rho = -0.5

simus_pckg <- rRM(paramDf=paramDf, n=n, model=model, time_scaled = time_scaled, gamma=FALSE, agg_simus=FALSE,
                  stimulus=stimulus, delta=delta, maxrt = maxrt)
simus_pckg <- filter(simus_pckg, response !=0)

paramDf2 <- paramDf
paramDf2$a <- paramDf2$a
paramDf2$b <- paramDf2$b
paramDf2$mu1 <- paramDf$v1
paramDf2$mu2 <- -paramDf$v1

simus_R <- rBoundedAcc(10000, c(paramDf2, rho=rho))
simus_R <- filter(simus_R, resp!=0)
names(simus_R) <- c("response", "rt", "conf")
simus_R$conf <- (c(paramDf2$b, paramDf2$a)[simus_R$response] - simus_R$conf)/(sqrt(simus_R$rt)^(as.numeric(time_scaled)))
simus_R$rating <- as.numeric(as.factor(cut(simus_R$conf, c(-Inf, paramDf[,paste("theta", 1:3, sep="")], Inf))))
head(simus_R)
head(simus_pckg)
simus <- rbind(cbind(simus_R, class="R"), cbind(simus_pckg[,c("response", "rt","conf", "rating")], class="pckg"))
ggplot(simus) +
  geom_density2d(aes(x=rt, y=conf, group=class, color=class))+
  facet_grid(.~response)
ggplot(filter(simus, rt<10)) +
  geom_density(aes(x=rt, group=rating, color=as.factor(rating)))+
  facet_grid(.~class)
simus_agg <- simus %>% group_by(class, response, rating) %>%
  summarise(p=n()/c(nrow(simus_pckg), nrow(simus_R))[as.numeric(.data$class[1]=="R")+1])
ggplot(simus_agg, aes(x=rating, y=p, fill=class))+
  geom_bar(stat = "identity", position="dodge")+
  facet_grid(response~.)








### Compare with computed density
## Compute density on observed range
rm(list=ls())
library(dynWEV)
library(tidyverse)
paramDf <- data.frame(v1=1,a=1.3, b=1.5, s=1, theta1 = 0.2, theta2= 1, theta3=2)
stimulus = c(1)
delta = 0.001
maxrt = 15
n = 5000
time_scaled=TRUE
model = "PCRM"
paramDf2 <- paramDf
paramDf2$mu1 <- paramDf2$v1
paramDf2$mu2 <- -paramDf2$v1
paramDf2$a <- -paramDf2$a
paramDf2$b <- -paramDf2$b

rRM_CPP(n, paramDf, model=model, delta=delta, maxrt = maxrt)
simus_pckg <- rRM(paramDf=paramDf, n=n, model=model, time_scaled = time_scaled, gamma=FALSE, agg_simus=FALSE,
                  stimulus=stimulus, delta=delta, maxrt = maxrt)
simus_pckg <- filter(simus_pckg, response !=0)

range <- expand.grid(xj=seq(quantile(simus_pckg$xj, probs = c(0.2)), 0, length.out = 200),
                     rt=seq(0, quantile(simus_pckg$rt, probs = 0.8), length.out = 200),
                     response=c(1,2))
paramDf$mu1 <- paramDf$v1
paramDf$mu2 <- -paramDf$v1
range$density <- ddPCRM(range$rt, range$response, range$xj, paramDf)



library(RColorBrewer)
rf <- colorRampPalette(rev(brewer.pal(11,'Spectral')))
r <- rf(32)
ggplot(range)+
  geom_tile(aes(x=xj, y=rt, fill=density))+
  scale_fill_gradientn(colours=r)+
  geom_density2d(data=simus_pckg, aes(x=xj, y=rt), bins=15)+
  ggtitle(paste("Mu: ", paramDf$mu1, ", ", paramDf$mu2, " with short formula (panels show responses)", sep=""))+
  facet_wrap(~response, nrow=2)+
  xlim(c(min(range$xj), 0))+ylim(c(0,max(range$rt)))+
  theme_minimal()


range <- expand.grid(xj=seq(min(simus_pckg$xj), 0, length.out = 400),
                     rt=seq(0.0001, max(simus_pckg$rt), length.out = 400),
                     response=c(1,2))
paramDf$mu1 <- paramDf$v1
paramDf$mu2 <- -paramDf$v1
range$density <- ddPCRM(range$rt, range$response, range$xj, paramDf)
preds <- range %>% group_by(response) %>%
  summarise(p = sum(density) * (sort(unique(rt))[5]-sort(unique(rt))[4])*(sort(unique(xj))[5]-sort(unique(xj))[4]))



## Compare to computed RT-densities for ratings:

head(simus_pckg)
paramDf$mu1 <- paramDf$v1
paramDf$mu2 <- -paramDf$v1
thetas <- c(0, as.numeric(t(paramDf[,paste("theta", 1:3, sep="")])), 1e+32)

range <- expand.grid(rating=1:4,
                     response=c(1,2)) %>%
  mutate(th1 = thetas[rating],
         th2 = thetas[rating+1]) %>%
  group_by(rating, response) %>%
  summarise(rt = seq(0.0001, quantile(simus_pckg$rt, probs = 0.95), length.out = 500),
            density = dPCRM(seq(0.0001, quantile(simus_pckg$rt, probs = 0.95), length.out = 500),
                           .data$response, c(paramDf, th1=th1, th2=th2), time_scaled = TRUE)) %>%
  mutate(rating=factor(rating, levels=1:4, labels=c("Guessing", "unsure", "a bit sure", "completely sure")),
         response=factor(response,levels=1:2, labels=c("Correct", "Wrong")))
simus_pckg <- simus_pckg %>%
  mutate(rating=factor(rating, levels=1:4, labels=c("Guessing", "unsure", "a bit sure", "completely sure")),
         response=factor(response,levels=1:2, labels=c("Correct", "Wrong")))
# install.packages("ggpubr")
#library(ggpubr)
p1 <- ggplot()+
  geom_density(data=simus_pckg, aes(x=rt, fill=interaction(rating, response), group=interaction(rating, response), y=..count../nrow(simus_pckg)),
               position ="stack", bw=0.07)+
  xlim(c(0,quantile(simus_pckg$rt, probs = 0.95) ))
p2 <- ggplot(range)+
  geom_area(data=range, aes(x=rt, y=density,fill=interaction(rating, response), group=interaction(rating, response)),
            position = "stack", stat = "identity")
ggarrange(p1, p2, common.legend = TRUE, legend = "bottom")



p1 <- ggplot()+
  geom_density(data=simus_pckg, aes(x=rt, fill=interaction(rating, response), group=interaction(rating, response), y=..count../nrow(simus_pckg)),
               position ="fill", bw=0.07)+
  xlim(c(0,quantile(simus_pckg$rt, probs = 0.95) ))
p2 <- ggplot(range)+
  geom_area(data=range, aes(x=rt, y=density,fill=interaction(rating, response), group=interaction(rating, response)),
            position = "fill", stat = "identity")
ggarrange(p1, p2, common.legend = TRUE, legend = "bottom")





ggplot(simus_pckg) +
  geom_density(aes(x=rt, colour="Simus", group=rating, y=..count../nrow(simus_pckg)))+
  geom_line(data=range, aes(x=rt, y=density, colour="Comp", group=response))+
  facet_grid(response~rating)+
  xlim(c(0,quantile(simus_pckg$rt, probs = 0.95) ))
pred <- range %>% group_by(rating, response) %>%
  summarise(p=sum(density)* (rt[5]-rt[4]))
aggSimus <- simus_pckg %>% group_by(response, rating) %>%
  summarise(p=n()/nrow(simus_pckg))
sum(aggSimus$p)
sum(pred$p)








############## Now for IRM   ################
### Compare with computed density
## Compute density on observed range
rm(list=ls())
library(dynWEV)
library(tidyverse)
paramDf <- data.frame(v1=0.5,a=0.8, b=0.78, s=1, theta1 = 0.2, theta2= 1, theta3=2)
stimulus = c(1)
delta = 0.002
maxrt = 15
n = 50000
time_scaled=TRUE
model = "IRM"
simus_pckg <- rRM(paramDf=paramDf, n=n, model=model, time_scaled = time_scaled, gamma=FALSE, agg_simus=FALSE,
                  stimulus=stimulus, delta=delta, maxrt = maxrt)
simus_pckg <- filter(simus_pckg, response !=0)

range <- expand.grid(xj=seq(quantile(simus_pckg$xj, probs = c(0.2)), 0, length.out = 200),
                     rt=seq(0.0001, quantile(simus_pckg$rt, probs = 0.8), length.out = 200),
                     response=c(1,2))
paramDf$mu1 <- paramDf$v1
paramDf$mu2 <- -paramDf$v1
range$density <- ddIRM(range$rt, range$response, range$xj, paramDf)



library(RColorBrewer)
rf <- colorRampPalette(rev(brewer.pal(11,'Spectral')))
r <- rf(32)
p1 <- ggplot(range)+
  geom_tile(aes(x=xj, y=rt, fill=density))+
  scale_fill_gradientn(colours=r)+
  geom_density2d(data=simus_pckg, aes(x=xj, y=rt), bins=30)+
  ggtitle(paste("Mu: ", paramDf$mu1, ", ", paramDf$mu2, " with short formula (panels show responses)", sep=""))+
  facet_wrap(~response, nrow=2)+
  xlim(c(min(range$xj), 0))+ylim(c(0,max(range$rt)))+
  theme_minimal()
p1



range <- expand.grid(xj=seq(min(simus_pckg$xj), 0, length.out = 400),
                     rt=seq(0.0001, max(simus_pckg$rt), length.out = 400),
                     response=c(1,2))
paramDf$mu1 <- paramDf$v1
paramDf$mu2 <- -paramDf$v1
range$density <- ddPCRM(range$rt, range$response, range$xj, paramDf)
preds <- range %>% group_by(response) %>%
  summarise(p = sum(density) * (sort(unique(rt))[5]-sort(unique(rt))[4])*(sort(unique(xj))[5]-sort(unique(xj))[4]))



## Compare to computed RT-densities for ratings:

head(simus_pckg)
paramDf$mu1 <- paramDf$v1
paramDf$mu2 <- -paramDf$v1
thetas <- c(0, as.numeric(t(paramDf[,paste("theta", 1:3, sep="")])), 1e+32)
range <- expand.grid(rating=1:4,
                     response=c(1,2)) %>%
  mutate(th1 = thetas[rating],
         th2 = thetas[rating+1]) %>%
  group_by(rating, response) %>%
  summarise(rt = seq(0.0001, quantile(simus_pckg$rt, probs = 0.95), length.out = 500),
            density = dIRM(seq(0.0001, quantile(simus_pckg$rt, probs = 0.95), length.out = 500),
                            .data$response, c(paramDf, th1=th1, th2=th2), time_scaled = TRUE)) %>%
  mutate(rating=factor(rating, levels=1:4, labels=c("Guessing", "unsure", "a bit sure", "completely sure")),
         response=factor(response,levels=1:2, labels=c("Correct", "Wrong")))
simus_pckg <- simus_pckg %>%
  mutate(rating=factor(rating, levels=1:4, labels=c("Guessing", "unsure", "a bit sure", "completely sure")),
         response=factor(response,levels=1:2, labels=c("Correct", "Wrong")))
# install.packages("ggpubr")
#library(ggpubr)
p1 <- ggplot()+
  geom_density(data=simus_pckg, aes(x=rt, fill=interaction(rating, response), group=interaction(rating, response), y=..count../nrow(simus_pckg)),
               position ="stack", bw=0.07)+
  xlim(c(0,quantile(simus_pckg$rt, probs = 0.95) ))
p2 <- ggplot(range)+
  geom_area(data=range, aes(x=rt, y=density,fill=interaction(rating, response), group=interaction(rating, response)),
            position = "stack", stat = "identity")
ggarrange(p1, p2, common.legend = TRUE, legend = "bottom")



p1 <- ggplot()+
  geom_density(data=simus_pckg, aes(x=rt, fill=interaction(rating, response), group=interaction(rating, response), y=..count../nrow(simus_pckg)),
               position ="fill", bw=0.03)+
  xlim(c(0,quantile(simus_pckg$rt, probs = 0.95) ))
p2 <- ggplot(range)+
  geom_area(data=range, aes(x=rt, y=density,fill=interaction(rating, response), group=interaction(rating, response)),
            position = "fill", stat = "identity")
ggarrange(p1, p2, common.legend = TRUE, legend = "bottom")


ggplot(simus_pckg) +
  geom_density(aes(x=rt, colour="Simus", group=rating, y=..count../nrow(simus_pckg)))+
  geom_line(data=range, aes(x=rt, y=density, colour="Comp", group=response))+
  facet_grid(response~rating)+
  xlim(c(0,quantile(simus_pckg$rt, probs = 0.95) ))
pred <- range %>% group_by(rating, response) %>%
  summarise(p=sum(density)* (rt[5]-rt[4]))
aggSimus <- simus_pckg %>% group_by(response, rating) %>%
  summarise(p=n()/nrow(simus_pckg))
sum(aggSimus$p)
sum(pred$p)


predConf <- predictRM_Conf(paramDf, "IRM", time_scaled=TRUE,maxrt = 20 , subdivisions = 1000 )
ggplot()+
  geom_bar(data=aggSimus, aes(x=rating, y=p, fill=as.factor(response)), stat="identity", position="dodge")+
  geom_point(data=filter(predConf, stimulus==1), aes(x=rating, y=p, shape=as.factor(response)), position = position_dodge(1))
sum(predConf$p)
