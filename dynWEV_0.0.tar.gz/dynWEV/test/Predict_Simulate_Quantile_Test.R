##### Test of prediction and simulations   ####
library(dynWEV)
library(tidyverse)





##### Test for 2DSD  ####
paramDf <- data.frame(setNames(as.list(c(1.941559, 1.214359e-06, 0.07138471, 0.3850766, 1.251469, 1.988679, 0.7329946,
                                         0.4887796, 0.2297651, 0.08065347, 0.465843, 3.068315, 3.237605, 3.689545,  4.713093,
                                         5.581823, -1.685472,  -2.197651, -3.14671, -4.03038)),
                               c("a", "v1", "v2", "v3", "v4", "v5", "sv", "z", "sz", "t0","st0","tau",
                                 "thetaUpper1", "thetaUpper2", "thetaUpper3", "thetaUpper4", "thetaLower1", "thetaLower2", "thetaLower3", "thetaLower4")))
# paramDf <- data.frame(setNames(as.list(c(1.941559, 1.214359e-06, 0.07138471, 0.3850766, 1.251469, 1.988679, 0.7329946,
#                                          0.9489944, 0.2297651, 0.08065347, 0.465843, 3.068315, 3.237605, 3.689545,  4.713093,
#                                          5.581823, -4.03038, -3.14671 , -2.197651, -1.685472)),
#                                c("a", "v1", "v2", "v3", "v4", "v5", "sv", "z", "sz", "t0","st0","tau",
#                                  "thetaUpper1", "thetaUpper2", "thetaUpper3", "thetaUpper4", "thetaLower1", "thetaLower2", "thetaLower3", "thetaLower4")))
#

model ="2DSD"
preds <- predictWEV_Conf(paramDf, model)
head(preds)


#### compare with simulations #####
n <- 500
nRatings <- 5
nConds <- 5
simus <- simulateWEV(paramDf, n=n, model=model, gamma=TRUE)
simus_plot <- simus$simus %>% group_by(rating, correct, condition) %>%
  summarise(p = n()/(n*2)) %>%
  full_join(y=expand.grid(rating=1:nRatings, condition=1:nConds,
                          correct=c(0,1))) %>%
  mutate(p = ifelse(is.na(p), 0, p))
sum(simus_plot$p)
simus_plot %>% group_by(condition, correct) %>% summarise(p=sum(p))
ggplot(preds, aes(x=rating, y=p, fill=as.factor(correct)))+
  geom_bar(stat = "identity", position = "dodge")+
  geom_point(data=simus_plot, position = position_dodge(1))+
  facet_grid(rows=vars(condition), cols = vars(correct))



#### Predcit RT distribution  ###
subdivisions = 300
maxrt = 9
scaled=FALSE
DistConf = NULL
if (exists("preds")) {
  DistConf <- preds
}
model = "2DSD"
precision = 3
c_precision = 100
pred_RT <- predictWEV_RT(paramDf, model,
                               precision=precision, c_precision = c_precision,
                               subdivisions = subdivisions, maxrt=maxrt, minrt=0,
                               scaled=TRUE,
                               DistConf = DistConf, .progress=TRUE)

quant_RT <- RTDensityToQuantiles(pred_RT, agg_over = c("stimulus"), ignore="response")





### Test with WEVmu ###
load("test/example_paramDf_WEVmu.RData")
paramDf$z <- paramDf$z/paramDf$a
preds <- predictDistWEV_Conf(paramDf)  # default model is WEVmu
head(preds)
#barplot(p~rating+correct, preds)

ggplot(preds, aes(x=rating, y=p, fill=as.factor(response)))+
  geom_bar(stat = "identity", position = "dodge")+
  facet_grid(rows=vars(stimulus), cols=vars(response))
n <- 800
nRatings <- 5
nConds <- 5
model <- "WEVmu"
simus <- simulateWEV(paramDf, n=n, model=model, gamma=TRUE)

simus_plot <- simus$simus %>% group_by(rating, correct, condition) %>%
  summarise(p = n()/(2*n)) %>%
  full_join(y=expand.grid(rating=1:nRatings, condition=1:nConds,
                          correct=c(0,1))) %>%
  mutate(p = ifelse(is.na(p), 0, p))
sum(simus_plot$p)
simus_plot %>% group_by(condition, correct) %>% summarise(p=sum(p))
ggplot(preds, aes(x=rating, y=p, fill=as.factor(correct)))+
  geom_bar(stat = "identity", position = "dodge")+
  geom_point(data=simus_plot, position = position_dodge(1))+
  facet_grid(rows=vars(condition), cols = vars(correct))


subdivisions = 300
maxrt = 9
scaled=FALSE
DistConf = NULL
if (exists("preds")) {
  DistConf <- preds
}
model = "WEVmu"
precision = 3
c_precision = 100
pred_RT <- predictDistWEVmu_RT(paramDf, "WEVmu",
                               precision=precision, c_precision = c_precision,
                               subdivisions = subdivisions, maxrt=maxrt, scaled=TRUE,
                               DistConf = DistConf)
pred_RT <- pred_RT %>% group_by(rt, correct, condition, rating)%>%
  summarise(densscaled=mean(.data$densscaled),
            dens = mean(.data$dens))
head(pred_RT)
ggplot()+
  geom_line(data=pred_RT, aes(x=rt, y=dens, col=as.factor(correct)))+
  facet_wrap(~condition+rating)

ggplot()+
  geom_density(data=simus$simus, aes(x=rt, col=as.factor(correct)))+
  geom_line(data=pred_RT, aes(x=rt, y=densscaled, col=as.factor(correct)))+
  facet_wrap(~condition+rating)
ggplot()+
  geom_density(data=subset(simus$simus, condition==3), aes(x=rt, col=as.factor(correct), linetype="simulation"), size=1.2, bw=0.2)+
  geom_line(data=subset(pred_RT, condition==3), aes(x=rt, y=densscaled, col=as.factor(correct), linetype="prediction"), size=1.2)+
  facet_wrap(~rating)+
  ggtitle("Panels represent different confidence ratings")
ggplot()+
  geom_density(data=subset(simus$simus, condition==3), aes(x=rt, col=as.factor(correct), linetype="simulation"), size=1.2, bw=0.2)+
  geom_line(data=subset(pred_RT, condition==3), aes(x=rt, y=densscaled, col=as.factor(correct), linetype="prediction"), size=1.2)+
  facet_wrap(~rating)+
  ggtitle("Panels represent different confidence ratings")

### Test of Quantile Computation  ###
p = c(.1,.3,.5,.7,.9)
agg_over = NULL
ignore = NULL




### Test with WEVabsmu ###
load("test/example_paramDf_WEVmu.RData")
paramDf$z <- paramDf$z/paramDf$a
paramDf$sigmu <- 0.5
paramDf$w <- 0.8
paramDf$tau <- 2
preds <- predictDistWEV_Conf(paramDf, model="WEVabsmu", c_precision = 100)  # default model is WEVmu
head(preds)
sum(preds$p)
preds %>% group_by(condition, stimulus) %>% summarise(p=sum(p))
#barplot(p~rating+correct, preds)
library(ggplot2)
ggplot(preds, aes(x=rating, y=p, fill=as.factor(response)))+
  geom_bar(stat = "identity", position = "dodge")+
  facet_grid(rows=vars(stimulus), cols=vars(response))
preds <- preds %>% group_by(rating, correct, condition) %>%
  summarise(p=mean(p))
preds %>% group_by(condition, correct) %>% summarise(p=sum(p))
n <- 500
nRatings <- 5
nConds <- 5
model <- "WEVabsmu"
simus <- simulateWEV(paramDf, n=n, model=model, gamma=TRUE)
simus_plot <- simus$simus %>% group_by(rating, correct, condition) %>%
  summarise(p = n()/(2*n)) %>%
  full_join(y=expand.grid(rating=1:nRatings, condition=1:nConds,
                          correct=c(0,1))) %>%
  mutate(p = ifelse(is.na(p), 0, p))
sum(simus_plot$p)
simus_plot %>% group_by(condition, correct) %>% summarise(p=sum(p))
ggplot(preds, aes(x=rating, y=p, fill=as.factor(correct)))+
  geom_bar(stat = "identity", position = "dodge")+
  geom_point(data=simus_plot, position = position_dodge(1))+
  facet_grid(rows=vars(condition), cols = vars(correct))






### Test with WEVd ###
load("test/example_paramDf_WEVmu.RData")
paramDf$z <- paramDf$z/paramDf$a
paramDf$tau <- 1
paramDf$w <- 0.9
preds <- predictDistWEV_Conf(paramDf, model="WEVd")  # default model is WEVmu
head(preds)
sum(preds$p)
preds %>% group_by(condition, stimulus) %>% summarise(p=sum(p))
#barplot(p~rating+correct, preds)
library(ggplot2)
ggplot(preds, aes(x=rating, y=p, fill=as.factor(response)))+
  geom_bar(stat = "identity", position = "dodge")+
  facet_grid(rows=vars(stimulus), cols=vars(response))
preds <- preds %>% group_by(rating, correct, condition) %>%
  summarise(p=mean(p))
preds %>% group_by(condition, correct) %>% summarise(p=sum(p))
n <- 500
nRatings <- 5
nConds <- 5
model <- "WEVd"
simus <- simulateWEV(paramDf, n=n, model=model, gamma=TRUE)
simus_plot <- simus$simus %>% group_by(rating, correct, condition) %>%
  summarise(p = n()/(2*n)) %>%
  full_join(y=expand.grid(rating=1:nRatings, condition=1:nConds,
                          correct=c(0,1))) %>%
  mutate(p = ifelse(is.na(p), 0, p))
sum(simus_plot$p)
simus_plot %>% group_by(condition, correct) %>% summarise(p=sum(p))
ggplot(preds, aes(x=rating, y=p, fill=as.factor(correct)))+
  geom_bar(stat = "identity", position = "dodge")+
  geom_point(data=simus_plot, position = position_dodge(1))+
  facet_grid(rows=vars(condition), cols = vars(correct))


