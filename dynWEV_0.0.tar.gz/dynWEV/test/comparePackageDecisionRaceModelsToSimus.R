### Here, I simulate and test the correctness of the 2DSD implementation in the package WITHOUT intertrial variability
### I.e. in the Ratcliff model, set sv=0, st0=0 and sv=0.
# 1. Simulate the model and confidence outcomes and Aggregate Rating Distribution####
# 2. Compute the distribution of confidence judgements with my own methods  ####
# 3. compute the rating distribution and the density of RT on observed range and the conf distribution with my package   ####
# 4. Plot the distributions of simulations and the package together ####
########################



# 0. Load packages and set parameter set:
cat("\014")
rm(list=ls())
library(tidyverse)
library(dynWEV)

load("../AccumulatorModels/saved_data/fits_DecisionRacingModels.RData")
nConds <- 3
nRatings <-1
trimmean <- function(x) {
  x <- x[x<100]
  mean(x)
}
paramDf <- fits_RMdecmodels %>% group_by(model) %>%
  summarise(across(.cols = 1:8, .fns = trimmean)) %>%
  select(-c("v1", "v4")) %>% rename(v1=v2, v2=v3, v3=v5) %>%
  mutate(t0 = 0.25, st0=0.15)

# 1. Simulate the model and confidence outcomes and Aggregate Rating Distribution####
n <- 10^4
## Simulations
simus <- paramDf %>% group_by(model) %>%
  summarise(rRM(cur_data(), n = n, model = .data$model, time_scaled = FALSE, gamma = FALSE, agg_simus = FALSE))

## Aggregate Rating Distribution
Agg_RatingDist_Simus <- simus %>% filter(response !=0) %>%
  group_by(correct,response, model, condition) %>%
  summarise(p = n()/(n)) %>%
  full_join(y=expand.grid(correct=c(0,1), condition = 1:nConds,response=1:2,
                          model=c("IRM","PCRM"))) %>%
  mutate(p = ifelse(is.na(p), 0, p))
sum(Agg_RatingDist_Simus$p)
Agg_RatingDist_Simus %>% group_by(condition, model) %>% summarise(p=sum(p))


# 3. Predict the rating distribution with my package   ####
## Rating Distribution
preds_pckg <- paramDf %>% group_by(model) %>%
  summarise(predictRM_Conf(cur_data(),model=cur_data_all()$model[1], time_scaled=FALSE,.progress = TRUE))
preds_pckg %>% group_by(condition, model) %>% summarise(p=sum(p))

temp <- subset(preds_pckg, model=="IRM" & condition ==1)
sum(temp$p + temp$err)

preds_RT <- paramDf %>% group_by(model) %>%
  summarise(predictRM_RT(cur_data(), model=cur_data_all()$model[1], time_scaled = FALSE, .progress = TRUE,
                        maxrt = max(simus$rt), subdivisions = 300, scaled=TRUE,
                        DistConf = subset(preds_pckg, model==cur_data_all()$model[1])))
Agg_preds_RT  <- preds_RT %>% group_by(model, rt, condition, correct) %>%
  summarise(dens=mean(dens), densscaled=mean(densscaled))


# 4. Plot the distributions of simulations and the package together ####

p <- ggplot(data=Agg_RatingDist_Simus, aes(x=correct, y=p, fill=as.factor(response)))+
  geom_bar(position="dodge", stat = "identity")+
  geom_point(data=preds_pckg,aes(shape="package"), position=position_dodge(1), col="black")+
  facet_wrap(model~condition)
p

simus2 <- simus %>% filter(rt<5)
dplot <- ggplot()+
  geom_density(data=simus2, aes(x=rt, y=2*nConds*..count../nrow(simus2), col=as.factor(correct), lty="simus"))+
  geom_line(data=Agg_preds_RT, aes(x=rt, y=dens, col=as.factor(correct), lty="comp"))+
  facet_grid(rows=vars(condition), cols = vars(model), labeller = labeller(response=label_value, rating=label_both))+
  xlim(c(0,5))
dplot

dplot <- ggplot()+
  geom_density(data=simus2, aes(x=rt, y=..density.., col=as.factor(correct), lty="simus"), bw=0.12)+
  geom_line(data=Agg_preds_RT, aes(x=rt, y=densscaled, col=as.factor(correct), lty="comp"))+
  facet_grid(rows=vars(condition), cols = vars(model), labeller = labeller(response=label_value, rating=label_both))+
  xlim(c(0,5))
dplot


# ggplot()+
#   geom_line(data=df, aes(x=rt, y=dens, col=response, lty="comp"), size=1.1)+
#   facet_grid(rows=vars(response), cols = vars(rating))

save.image(file="package_test/test_WEV/TSDSDT_samplesNcomputattions.RData")

