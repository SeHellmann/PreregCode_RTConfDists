library(dynWEV)
library(tidyverse)

load("../AccumulatorModels/saved_data/fits_RacingModels.RData")
fits_part1 <- subset(fits_RMmodels, model=="PCRMt" & participant==1) %>%
  mutate(wrt=0, wint=0, w=0, st0=0) %>%
  mutate(a = mean(a, b), b=mean(a, b))

load("test/dataRausch2018.RData")
data_part1 <- subset(Data, participant==1)
head(data_part1)
stim_levels <- unique(data_part1$stimulus)
data_part1 <- data_part1 %>%
  mutate(condition = as.numeric(as.factor(condition)),
         stimulus = as.numeric(factor(stimulus, levels=stim_levels)),
         response = as.numeric(factor(response, levels=stim_levels)))
dat_point <- filter(data_part1, stimulus == 1 & response == 1 & rating == 3 & condition == 4)





paramDf <- data.frame(a=fits_part1$a, b = fits_part1$b, mu1 = fits_part1$v1, mu2 = -fits_part1$v1,
                      s = fits_part1$s,
                      th1 = c(0, as.numeric(fits_part1[,paste0("thetaUpper", 1:4)])),
                      th2 = c(as.numeric(fits_part1[,paste0("thetaUpper", 1:4)]), 1e+52),
                      wrt = 0.5, wint = 1, t0 = 0.1, st0=0.2)
res1 <- dPCRM(rep(dat_point$rt, 5), response=1, params = paramDf, time_scaled = TRUE)
paramDf[,1:8] <- paramDf[,1:8]/paramDf$s
res2 <- dPCRM(rep(dat_point$rt, 5), response=1, params = paramDf, time_scaled = TRUE)
res1 == res2
plot(res1, res1-res2)
abline(a=0, b=1)

paramDf$s <- NULL
res3 <- dPCRM(rep(dat_point$rt, 5), response=1, params = paramDf, time_scaled = TRUE)
res2==res3

paramDf <- data.frame(a=fits_part1$a, b = fits_part1$b, mu1 = fits_part1$v1, mu2 = -fits_part1$v1,
                      s = fits_part1$s,
                      th1 = c(0, as.numeric(fits_part1[,paste0("thetaLower", 1:4)])),
                      th2 = c(as.numeric(fits_part1[,paste0("thetaLower", 1:4)]), 1e+52),
                      wrt = 0.5, wint = 1, t0 = 0.1, st0=0.2)
res1 <- dPCRM(rep(dat_point$rt, 5), response=2, params = paramDf, time_scaled = TRUE)

paramDf[,1:8] <- paramDf[,1:8]*2
res2 <- dPCRM(rep(dat_point$rt, 5), response=2, params = paramDf, time_scaled = TRUE)
res1 == res2

paramDf$s <- NULL
res3 <- dPCRM(rep(dat_point$rt, 5), response=2, params = paramDf, time_scaled = TRUE)
res2==res3
plot(res1, res1-res2)
abline(a=0, b=1)


paramDf <- data.frame(a=fits_part1$a, b = fits_part1$b, mu1 = -fits_part1$v1, mu2 = fits_part1$v1,
                      s = fits_part1$s,
                      th1 = c(0, as.numeric(fits_part1[,paste0("thetaUpper", 1:4)])),
                      th2 = c(as.numeric(fits_part1[,paste0("thetaUpper", 1:4)]), 1e+52),
                      wrt = 0.5, wint = 1, t0 = 0.1, st0=0.2)
res1 <- dPCRM(rep(dat_point$rt, 5), response=1, params = paramDf, time_scaled = TRUE)
paramDf[,1:8] <- paramDf[,1:8]*0.0099
res2 <- dPCRM(rep(dat_point$rt, 5), response=1, params = paramDf, time_scaled = TRUE)
res1 == res2

paramDf$s <- NULL
res3 <- dPCRM(rep(dat_point$rt, 5), response=1, params = paramDf, time_scaled = TRUE)
res2==res3
plot(res1, res1-res2)
abline(a=0, b=1)



paramDf <- data.frame(a=fits_part1$a, b = fits_part1$b, mu1 = -fits_part1$v1, mu2 = fits_part1$v1,
                      s = fits_part1$s,
                      th1 = c(0, as.numeric(fits_part1[,paste0("thetaLower", 1:4)])),
                      th2 = c(as.numeric(fits_part1[,paste0("thetaLower", 1:4)]), 1e+52),
                      wrt = 0.5, wint = 1, t0 = 0.1, st0=0.2)
res1 <- dPCRM(rep(dat_point$rt, 5), response=2, params = paramDf, time_scaled = TRUE)

paramDf[,1:8] <- paramDf[,1:8]*2
res2 <- dPCRM(rep(dat_point$rt, 5), response=2, params = paramDf, time_scaled = TRUE)
res1 == res2








fits_part1 <- subset(fits_RMmodels, model=="PCRMt" & participant==1) %>%
  mutate(wrt=0, wint=0, w=0, st0=0) %>%
  mutate(a = mean(a, b), b=mean(a, b))
data_part1 <- subset(Data, participant==1)
head(data_part1)
stim_levels <- unique(data_part1$stimulus)
data_part1 <- data_part1 %>%
  mutate(condition = as.numeric(as.factor(condition)),
         stimulus = as.numeric(factor(stimulus, levels=stim_levels)),
         response = as.numeric(factor(response, levels=stim_levels)))

dynWEV::LogLikRM(data_part1, fits_part1, model=fits_part1$model)
# [1] -1985.463
dynWEV::LogLikRM(data_part1, fits_part1, model="PCRM")
# [1] -1985.463
fits_part1[c(3:5, 8:20, 28, 29)]
fits_part1[c(3:5, 8:20, 28, 29)] <- fits_part1[c(3:5, 8:20, 28, 29)]*2
#fits_part1$s <- fits_part1$s *2
fits_part1[c(3:5, 8:20, 28, 29)]
dynWEV::LogLikRM(data_part1, fits_part1, model=fits_part1$model)




dynWEV::LogLikRM(data_part1, fits_part1, model="IRM")
# [1] -1985.463
dynWEV::LogLikRM(data_part1, fits_part1, model="IRM")
# [1] -1985.463
fits_part1[c(3:5, 8:20, 28, 29)]
fits_part1[c(3:5, 8:20, 28, 29)] <- fits_part1[c(3:5, 8:20, 28, 29)]*2
fits_part1[c(3:5, 8:20, 28, 29)]

dynWEV::LogLikRM(data_part1, fits_part1, model="IRM")









fits_part1
range <- expand.grid(xj = seq(-fits_part1$a/6, fits_part1$a-1e-4, length.out=10),
                     rt = seq(0.3, 1.5, length.out=10),
                     response= c(1,2), condition = 1:5,
                     a=fits_part1$a, b = fits_part1$b, s=fits_part1$s) %>%
  mutate(mu1 = as.numeric(fits_part1[, paste0("v", 1:5)])[condition],
         mu2 = -as.numeric(fits_part1[, paste0("v", 1:5)])[condition])
range$density <- ddPCRM(range$rt,range$response, range$xj,range)

fac <- 2
range2 <- expand.grid(xj = seq(-fits_part1$a/6, fits_part1$a-1e-4, length.out=10)*fac,
                      rt = seq(0.3, 1.5, length.out=10),
                      response= c(1,2), condition = 1:5,
                      a=fits_part1$a*fac, b = fits_part1$b*fac, s=fits_part1$s*fac) %>%
  mutate(mu1 = as.numeric(fits_part1[, paste0("v", 1:5)])[condition]*fac,
         mu2 = -as.numeric(fits_part1[, paste0("v", 1:5)])[condition]*fac)
range2$density <- ddPCRM(range2$rt,range2$response, range2$xj,range2)*fac
range2$density - range$density





fits_part1
range <- expand.grid(xj = seq(-fits_part1$a/6, fits_part1$a-1e-4, length.out=10),
                     rt = seq(0.3, 1.5, length.out=10),
                     response= c(1,2), condition = 1:5,
                     a=fits_part1$a, b = fits_part1$b, s=fits_part1$s) %>%
  mutate(mu1 = as.numeric(fits_part1[, paste0("v", 1:5)])[condition],
         mu2 = -as.numeric(fits_part1[, paste0("v", 1:5)])[condition])
range$density <- ddIRM(range$rt,range$response, range$xj,range)

fac <- 2
range2 <- expand.grid(xj = seq(-fits_part1$a/6, fits_part1$a-1e-4, length.out=10)*fac,
                      rt = seq(0.3, 1.5, length.out=10),
                      response= c(1,2), condition = 1:5,
                      a=fits_part1$a*fac, b = fits_part1$b*fac, s=fits_part1$s*fac) %>%
  mutate(mu1 = as.numeric(fits_part1[, paste0("v", 1:5)])[condition]*fac,
         mu2 = -as.numeric(fits_part1[, paste0("v", 1:5)])[condition]*fac)
range2$density <- ddIRM(range2$rt,range2$response, range2$xj,range2)*fac
range2$density - range$density


dat_point <- filter(data_part1, stimulus == 1 & response == 1 & rating == 3 & condition == 4)


paramDf <- data.frame(a=fits_part1$a, b = fits_part1$b, mu1 = fits_part1$v1, mu2 = -fits_part1$v1,
                      s = fits_part1$s,
                      th1 = c(0, as.numeric(fits_part1[,paste0("thetaUpper", 1:4)])),
                      th2 = c(as.numeric(fits_part1[,paste0("thetaUpper", 1:4)]), 1e+52),
                      wrt = 0.5, wint = 1, t0 = 0.1, st0=0.2)
res1 <- dIRM(rep(dat_point$rt, 5), response=1, params = paramDf, time_scaled = TRUE)
paramDf[,1:8] <- paramDf[,1:8]*2
res2 <- dIRM(rep(dat_point$rt, 5), response=1, params = paramDf, time_scaled = TRUE)
res1 == res2
plot(res1, res1-res2)
abline(a=0, b=1)

paramDf <- data.frame(a=fits_part1$a, b = fits_part1$b, mu1 = fits_part1$v1, mu2 = -fits_part1$v1,
                      s = fits_part1$s,
                      th1 = c(0, as.numeric(fits_part1[,paste0("thetaLower", 1:4)])),
                      th2 = c(as.numeric(fits_part1[,paste0("thetaLower", 1:4)]), 1e+12),
                      wrt = 0.5, wint = 1, t0 = 0.1, st0=0.2)
res1 <- dIRM(rep(dat_point$rt, 5), response=2, params = paramDf, time_scaled = TRUE)

paramDf[,1:8] <- paramDf[,1:8]*2
res2 <- dIRM(rep(dat_point$rt, 5), response=2, params = paramDf, time_scaled = TRUE)
res1 == res2
plot(res1, res1-res2, pch=1:length(res1))
legend("bottomright", legend=1:length(res1),pch=1:length(res1))
abline(a=0, b=1)




paramDf <- data.frame(a=fits_part1$a, b = fits_part1$b, mu1 = -fits_part1$v1, mu2 = fits_part1$v1,
                      s = fits_part1$s,
                      th1 = c(0, as.numeric(fits_part1[,paste0("thetaUpper", 1:4)])),
                      th2 = c(as.numeric(fits_part1[,paste0("thetaUpper", 1:4)]), 1e+52),
                      wrt = 0.5, wint = 1, t0 = 0.1, st0=0.2)
res1 <- dIRM(rep(dat_point$rt, 5), response=1, params = paramDf, time_scaled = TRUE)
paramDf[,1:8] <- paramDf[,1:8]*2
res2 <- dIRM(rep(dat_point$rt, 5), response=1, params = paramDf, time_scaled = TRUE)
res1 == res2
paramDf <- data.frame(a=fits_part1$a, b = fits_part1$b, mu1 = -fits_part1$v1, mu2 = fits_part1$v1,
                      s = fits_part1$s,
                      th1 = c(0, as.numeric(fits_part1[,paste0("thetaLower", 1:4)])),
                      th2 = c(as.numeric(fits_part1[,paste0("thetaLower", 1:4)]), 1e+52),
                      wrt = 0.5, wint = 1, t0 = 0.1, st0=0.2)
res1 <- dIRM(rep(dat_point$rt, 5), response=2, params = paramDf, time_scaled = TRUE)

paramDf[,1:8] <- paramDf[,1:8]*2
res2 <- dIRM(rep(dat_point$rt, 5), response=2, params = paramDf, time_scaled = TRUE)
res1 == res2


