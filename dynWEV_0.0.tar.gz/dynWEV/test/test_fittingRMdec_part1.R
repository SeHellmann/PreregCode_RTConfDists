
cat("\014")
rm(list=ls())
library(dynWEV)
library(tidyverse)

# 1) Read in data
load("test/dataRausch2018.RData")
Data <- subset(Data, rt > .2 & rt <= 5.5)
data <- subset(Data, participant==1)
nrow(data)




model = "IRM"
method="ML"
logging=TRUE
opts=list(nAttempts=3, nRestarts=2, maxfun=5)
#source("R/internal_fcts_fitting_RM.R")
optim_method="Nelder-Mead"
optim_method = "bobyqa"
data_names = list()
mint0 <- min(data$rt)

#### Just to see good inits:
load("../AccumulatorModels/saved_data/fits_DecisionRacingModels.RData")
nConds <- 5
nRatings <-5
trimmean <- function(x) {
  x <- x[x<100]
  mean(x)
}
paramDf <- fits_RMdecmodels %>% group_by(model) %>%
  summarise(across(.cols = 1:8, .fns = trimmean))
#######
init_grid <- expand.grid(vmin=c(0.12, 0.2),
                         vmax=c(4.5,5, 5.5),
                         a = c(4.66, 5),
                         b = c(4.66, 5),
                         s=c(1.3, 2.5, 4), t0 = min(data$rt)-0.15, st0=0.1)
grid_search = TRUE


.parallel=TRUE
n.cores=3
###
fitRMdec(data, model, init_grid=init_grid, logging=logging,
      opts = opts, optim_method = optim_method,.parallel=TRUE, n.cores=3)


inits <- inits[sample(1:nrow(inits), size=floor(0.05*nrow(inits))),]
inits <- inits[sample(1:nrow(inits), size=floor(0.05*nrow(inits))),]
