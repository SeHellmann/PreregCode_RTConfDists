#### Density function in correlated two dimensional diffusion processes
######   Moreno-Bote (2010):  Decision Confidence & Uncertainty in Diff.Models
######                        with Partially Correlated Neural Integrators
######    Formulae (A.8) & (A.9)


### This function defines the combined probability of accumulator k reaching the boundary at
###   time t and the loosing accumulator being in state xj
dboundaccMorenoBote <-
  function(t, resp, xj, paramDf, formula="long"){
    ## INPUT:
    ##    Arguments (vectors):
    ##        xj                 state of loosing accumulator
    ##        resp              response (i.e. 1 or 2) representing the winning accumulator
    ##        t                 decision time: time until the accumulator reaches threshold

    ##    Parameters: paramDf (a list or one-row-df) with following entries
    ##        drift rates       mu_1, mu_2
    ##        variance          s in |R+
    ##        correlation       rho  (either -0.5 or 0)
    ##        boundary sep.    x01, x02 (starting points (negative); boundaries are fixed to 0)
    ##        precision         k   # number of terms calculated in series in function G

    ## Output:
    ##        vector of real values, giving the pdf

    rho = paramDf$rho
    if (!(rho %in% c(-0.5, 0))) stop(paste("Only possible for rho either -0.5 or 0; not ", rho, sep=""))

    Nobs <- length(t)

    sigma = as.numeric(paramDf[grep(names(paramDf), pattern = "s", value=TRUE)])
    a <- paramDf$a
    b <- paramDf$b
    B <- c(a,b)
    mu <- c(paramDf$mu1, paramDf$mu2)
    muu <- sum(mu)
    muv <- mu[1]-mu[2]

    if (any(c(sigma)<=0)) stop ("variance parameter must be strictly positive")
    if (any(B>0)) stop ("at least one starting point is greater  0; must be negative")
    if (!(all(resp %in% c(1,2)))) stop ("resp must be either 1 or 2")
    if (any(t <=0)) stop ("response time t must be strictly positive")

    if (formula=="short") {
      g_k <- function(xj, t, resp) {
        -B[resp]/(2*pi*sigma^2*t^2) * exp(-(B[resp]+t*mu[resp])^2/(2*sigma^2*t)) *
          (exp(-(xj-B[resp]-mu[3-resp]*t)^2/(2*sigma^2*t)) - exp(-(2*B[3-resp]*mu[3-resp])/sigma^2 - (xj+B[resp]-mu[3-resp]*t)^2/(2*sigma^2*t)))
      }
      g_k <- Vectorize(g_k)
      res <- g_k(xj, t, resp)
      res[res<0] <- 0
      return(res)
    } else {
      ## Define constants:
      if (rho==0) {
        C <- c(1, -exp(-2*B*mu/sigma^2))
        C[4] <- C[2]*C[3]
        X <- matrix(c(a, b,
                      -a, b,
                      a, -b,
                      -a, -b), byrow = TRUE, nrow=4)
        Sigma <- rep(sqrt(2)*sigma, 2)
      } else {
        C <- c(1, c(-1,-1,1,1,-1)*exp(-2/sigma^2 * (mu[1]*c(a, 0, a, a+b, a+b)+mu[2]*c(0, b, a+b, b, a+b))))
        X <- matrix(c(a, b,
                      -a, a+b,
                      a+b, -b,
                      b, -a-b,
                      -a-b,a,
                      -b,-a), byrow = TRUE, nrow=6)
        Sigma <- c(sigma, sqrt(3)*sigma)
      }

      sum_dPe_dx <- function(xj, t, resp) {
        fac <- -1/(pi*prod(Sigma)*t^2)
        temp <- C*((xj-(X[,1]+X[,2])-muu*t)/Sigma[1]^2 + (-1)^(resp+1)*((-1)^resp*xj-(X[,1]-X[,2])-muv*t)/Sigma[2]^2)
        temp <- temp*exp(-1/(2*t) * ((xj-(X[,1]+X[,2])-muu*t)^2/Sigma[1]^2 + ((-1)^resp*xj-(X[,1]-X[,2])-muv*t)^2/Sigma[2]^2))
        return(sum(temp)*fac)
      }
      sum_dPe_dx<- Vectorize(sum_dPe_dx)
      dens1 <- sum_dPe_dx(xj, t, resp)
      res <- dens1*(-sigma^2/2)
      res[res<0] <- 0
      return(res)
    }
}

