## Rebuilding the package
##
rm(list=ls())
rm(list = c(".onUnload"))
library(devtools)
library(roxygen2)
#roxygen2::roxygenise()
cat("\014")
#pkgbuild::compile_dll()
document()
## Test package:        Crtl + Shift + E
## Install, restart:  Crtl + Shift + B

#remotes::install_version("roxygen2", "6.1.0")
#install.packages("roxygen2")

#
# library(tools)
# # package_native_routine_registration_skeleton(".")
# tools::package_native_routine_registration_skeleton(".", character_only = FALSE)

#pkgload::load_all()
